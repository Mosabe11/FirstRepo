"""
Telegram notification handler.
Sends arbitrage alerts to a configured chat.
"""
import os
import httpx
from datetime import datetime

TELEGRAM_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")


async def send_alert(opportunity: dict) -> bool:
    """
    Send an arbitrage opportunity to Telegram.
    Returns True if sent successfully.
    """
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        print("⚠️  Telegram credentials missing. Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in .env")
        return False

    message = format_message(opportunity)
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"

    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.post(url, json=payload)
            response.raise_for_status()
            return True
    except Exception as e:
        print(f"❌ Telegram send failed: {e}")
        return False


def format_message(opp: dict) -> str:
    """Format opportunity into a nice Telegram message."""
    profit_emoji = "🔥" if opp["profit_percent"] >= 2 else "💰"

    return (
        f"{profit_emoji} <b>Arbitrage Opportunity</b>\n\n"
        f"<b>Pair:</b> {opp['pair']}\n"
        f"<b>Profit:</b> {opp['profit_percent']:.2f}%\n"
        f"<b>Spread:</b> ${opp['spread_usd']:.2f} on ${opp['test_amount']}\n\n"
        f"📈 <b>Buy on:</b> {opp['buy_route']}\n"
        f"   Price: ${opp['buy_price']:.6f}\n\n"
        f"📉 <b>Sell on:</b> {opp['sell_route']}\n"
        f"   Price: ${opp['sell_price']:.6f}\n\n"
        f"⏰ {datetime.now().strftime('%H:%M:%S')}\n"
        f"<i>⚠️ This is a paper alert. Verify before trading.</i>"
    )


async def send_startup_message():
    """Send a message when scanner starts."""
    if not TELEGRAM_TOKEN or not TELEGRAM_CHAT_ID:
        return

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": "🤖 <b>Solana Arbitrage Scanner Started</b>\n\nMonitoring for opportunities...",
        "parse_mode": "HTML",
    }

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(url, json=payload)
    except Exception as e:
        print(f"⚠️  Startup message failed: {e}")
