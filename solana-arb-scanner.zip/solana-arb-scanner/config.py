"""
Configuration: tokens to monitor and scanner settings.
All mint addresses verified from Solana token list.
"""

# Top tokens on Solana (mint addresses)
TOKENS = {
    "SOL":   "So11111111111111111111111111111111111111112",
    "USDC":  "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    "USDT":  "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
    "JUP":   "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN",
    "BONK":  "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263",
    "WIF":   "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm",
    "JTO":   "jtojtomepa8beP8AuQc6eXt5FriJwfFMwQx2v2f9mCL",
    "PYTH":  "HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3",
    "RAY":   "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R",
    "ORCA":  "orcaEKTdK7LKz57vaAYr9QeNsVEPfiu6QeMU1kektZE",
    "RNDR":  "rndrizKT3MK1iimdxRdWabcF7Zg7AR5T4nud4EkHBof",
    "MSOL":  "mSoLzYCxHdYgdzU16g5QSh3i5K3z3KZK7ytfqcJm7So",
    "WBTC":  "3NZ9JMVBmGAqocybic2c7LQCJScmgsAZ6vQqTDzcqmJh",
    "WETH":  "7vfCXTUXx5WJV5JADk17DUJ4ksgau7utNKj4b963voxs",
}

# Pairs we want to scan (base, quote)
# We compare prices when buying X with USDC vs other paths
PAIRS_TO_SCAN = [
    ("SOL",  "USDC"),
    ("JUP",  "USDC"),
    ("BONK", "USDC"),
    ("WIF",  "USDC"),
    ("JTO",  "USDC"),
    ("PYTH", "USDC"),
    ("RAY",  "USDC"),
    ("ORCA", "USDC"),
    ("RNDR", "USDC"),
    ("MSOL", "USDC"),
]

# Scanner settings
MIN_PROFIT_PERCENT = 1.0      # Minimum spread % to alert
TEST_AMOUNT_USDC = 100         # Amount in USDC to simulate trade with
SCAN_INTERVAL_SECONDS = 30     # How often to scan
ALERT_COOLDOWN_SECONDS = 300   # Don't spam the same opportunity (5 min)

# Jupiter API (free, no key needed)
JUPITER_QUOTE_API = "https://quote-api.jup.ag/v6/quote"

# Token decimals (needed for amount calculations)
DECIMALS = {
    "SOL": 9, "USDC": 6, "USDT": 6, "JUP": 6, "BONK": 5,
    "WIF": 6, "JTO": 9, "PYTH": 6, "RAY": 6, "ORCA": 6,
    "RNDR": 8, "MSOL": 9, "WBTC": 8, "WETH": 8,
}
