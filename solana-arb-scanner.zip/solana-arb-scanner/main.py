"""
Main entry point for the Solana Arbitrage Scanner.
Runs a continuous scan loop, alerting on profitable opportunities.
"""
import asyncio
import time
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()  # Load .env before importing modules that use env vars

from scanner import scan_all_pairs
from telegram_bot import send_alert, send_startup_message
from config import SCAN_INTERVAL_SECONDS, ALERT_COOLDOWN_SECONDS, MIN_PROFIT_PERCENT


# Track last alert time per pair to avoid spam
last_alert_times: dict[str, float] = {}


def should_alert(pair: str) -> bool:
    """Check if enough time has passed since last alert for this pair."""
    now = time.time()
    last = last_alert_times.get(pair, 0)
    if now - last >= ALERT_COOLDOWN_SECONDS:
        last_alert_times[pair] = now
        return True
    return False


async def main_loop():
    print("=" * 60)
    print("🤖 Solana Arbitrage Scanner")
    print(f"   Min profit: {MIN_PROFIT_PERCENT}%")
    print(f"   Scan interval: {SCAN_INTERVAL_SECONDS}s")
    print(f"   Alert cooldown: {ALERT_COOLDOWN_SECONDS}s")
    print("=" * 60)

    await send_startup_message()

    scan_count = 0
    total_alerts = 0

    while True:
        scan_count += 1
        print(f"\n[Scan #{scan_count} @ {datetime.now().strftime('%H:%M:%S')}]")

        try:
            opportunities = await scan_all_pairs()

            for opp in opportunities:
                if should_alert(opp["pair"]):
                    sent = await send_alert(opp)
                    if sent:
                        total_alerts += 1
                        print(f"   📨 Alert sent for {opp['pair']} (+{opp['profit_percent']:.2f}%)")
                else:
                    print(f"   🔕 {opp['pair']} on cooldown")

            print(f"   Total alerts so far: {total_alerts}")

        except Exception as e:
            print(f"❌ Scan error: {e}")

        await asyncio.sleep(SCAN_INTERVAL_SECONDS)


if __name__ == "__main__":
    try:
        asyncio.run(main_loop())
    except KeyboardInterrupt:
        print("\n👋 Scanner stopped.")
