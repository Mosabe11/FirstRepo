"""
Core arbitrage scanner.
Uses Jupiter v6 API to compare prices across Solana DEXs.

Strategy:
  1. Get quote: USDC -> TOKEN (with route info)
  2. Get quote: TOKEN -> USDC (with route info)
  3. If round-trip returns more USDC than we started with = arbitrage
  4. Jupiter automatically picks best route per direction;
     when buy and sell routes differ, that's the arbitrage spread.
"""
import asyncio
import httpx
from config import (
    TOKENS, DECIMALS, JUPITER_QUOTE_API,
    PAIRS_TO_SCAN, TEST_AMOUNT_USDC, MIN_PROFIT_PERCENT
)


async def get_quote(
    client: httpx.AsyncClient,
    input_mint: str,
    output_mint: str,
    amount: int,
) -> dict | None:
    """Get a quote from Jupiter for input_mint -> output_mint."""
    params = {
        "inputMint": input_mint,
        "outputMint": output_mint,
        "amount": amount,
        "slippageBps": 50,  # 0.5% slippage tolerance
        "onlyDirectRoutes": "false",
    }
    try:
        response = await client.get(JUPITER_QUOTE_API, params=params, timeout=10)
        if response.status_code != 200:
            return None
        return response.json()
    except Exception as e:
        print(f"⚠️  Quote error: {e}")
        return None


def extract_route_name(quote: dict) -> str:
    """Extract DEX names from a Jupiter quote route."""
    if not quote or "routePlan" not in quote:
        return "Unknown"
    dexs = []
    for step in quote["routePlan"]:
        label = step.get("swapInfo", {}).get("label", "?")
        if label not in dexs:
            dexs.append(label)
    return " → ".join(dexs) if dexs else "Direct"


async def check_pair(client: httpx.AsyncClient, base: str, quote_token: str) -> dict | None:
    """
    Check round-trip arbitrage: USDC -> TOKEN -> USDC.
    If we end up with more USDC than we started, there's a spread.
    """
    base_mint = TOKENS[base]
    quote_mint = TOKENS[quote_token]

    # Step 1: USDC -> BASE
    usdc_amount = TEST_AMOUNT_USDC * (10 ** DECIMALS[quote_token])
    buy_quote = await get_quote(client, quote_mint, base_mint, usdc_amount)
    if not buy_quote or "outAmount" not in buy_quote:
        return None

    base_received = int(buy_quote["outAmount"])
    base_human = base_received / (10 ** DECIMALS[base])
    buy_price = TEST_AMOUNT_USDC / base_human if base_human > 0 else 0

    # Step 2: BASE -> USDC (using exactly what we received)
    sell_quote = await get_quote(client, base_mint, quote_mint, base_received)
    if not sell_quote or "outAmount" not in sell_quote:
        return None

    usdc_received = int(sell_quote["outAmount"]) / (10 ** DECIMALS[quote_token])
    sell_price = usdc_received / base_human if base_human > 0 else 0

    # Calculate profit
    profit_usd = usdc_received - TEST_AMOUNT_USDC
    profit_percent = (profit_usd / TEST_AMOUNT_USDC) * 100

    buy_route = extract_route_name(buy_quote)
    sell_route = extract_route_name(sell_quote)

    return {
        "pair": f"{base}/{quote_token}",
        "test_amount": TEST_AMOUNT_USDC,
        "buy_route": buy_route,
        "sell_route": sell_route,
        "buy_price": buy_price,
        "sell_price": sell_price,
        "spread_usd": profit_usd,
        "profit_percent": profit_percent,
        "base_amount": base_human,
    }


async def scan_all_pairs() -> list[dict]:
    """Scan all configured pairs and return profitable opportunities."""
    opportunities = []

    async with httpx.AsyncClient() as client:
        tasks = [check_pair(client, base, quote) for base, quote in PAIRS_TO_SCAN]
        results = await asyncio.gather(*tasks, return_exceptions=True)

    for result in results:
        if isinstance(result, Exception) or result is None:
            continue

        # Log every check for transparency
        emoji = "🟢" if result["profit_percent"] >= MIN_PROFIT_PERCENT else "⚪"
        print(
            f"{emoji} {result['pair']:12s} | "
            f"spread: {result['profit_percent']:+.3f}% | "
            f"buy: {result['buy_route'][:25]:25s} | "
            f"sell: {result['sell_route'][:25]}"
        )

        if result["profit_percent"] >= MIN_PROFIT_PERCENT:
            opportunities.append(result)

    return opportunities
