# Solana Arbitrage Scanner 🤖

Python scanner that monitors Solana DEX prices via Jupiter API and sends Telegram alerts when arbitrage opportunities appear.

## How it works

For each pair, the scanner does a **round-trip simulation**:

```
$100 USDC  →  TOKEN  (best buy route, e.g. Raydium)
           ↓
TOKEN      →  USDC   (best sell route, e.g. Orca)
           ↓
Result: $101.50 USDC  →  +1.5% spread → ALERT
```

Jupiter automatically routes through whichever DEX gives the best price. When the buy route and sell route differ, that's the arbitrage spread.

## Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Create a Telegram bot
1. Open Telegram, search for **@BotFather**
2. Send `/newbot`, follow the prompts
3. Copy the token you receive

### 3. Get your chat ID
1. Search for **@userinfobot** on Telegram
2. Start a chat — it sends back your numeric chat ID

### 4. Configure
```bash
cp .env.example .env
# Edit .env and paste your token + chat ID
```

### 5. Run
```bash
python main.py
```

## Configuration

Edit `config.py`:

- `PAIRS_TO_SCAN` — which token pairs to monitor
- `MIN_PROFIT_PERCENT` — minimum spread to trigger alert (default 1%)
- `TEST_AMOUNT_USDC` — simulated trade size (default $100)
- `SCAN_INTERVAL_SECONDS` — how often to scan (default 30s)
- `ALERT_COOLDOWN_SECONDS` — anti-spam per pair (default 5 min)

## Important notes ⚠️

1. **Paper alerts only.** This scans and alerts. It does NOT execute trades. That's intentional for Phase 1.
2. **Real spreads are rare.** With Jupiter aggregating most liquidity, profitable spreads >1% on major pairs usually mean: (a) a brief inefficiency that disappears in seconds, (b) low liquidity on one side, or (c) a stale quote. Treat alerts as research data, not signals to trade blindly.
3. **By the time you see an alert and act, the spread is likely gone.** Real arb bots execute in milliseconds. The point of Phase 1 is to *verify opportunities exist* before investing in faster infrastructure.

## Project structure

```
solana-arb-scanner/
├── config.py          # Tokens, pairs, thresholds
├── scanner.py         # Core logic (Jupiter API calls)
├── telegram_bot.py    # Alert sender
├── main.py            # Scan loop
├── .env               # Your secrets (not in git)
└── requirements.txt   # Dependencies
```

## Next phases (later)

- **Phase 2**: Add wallet integration + auto-execute small trades
- **Phase 3**: Add MEV protection (Jito bundles)
- **Phase 4**: Move to a VPS close to Solana validators for lower latency
