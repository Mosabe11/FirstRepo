"""
core/signal.py — Shared Signal dataclass
"""
from dataclasses import dataclass, field
from typing import Literal, Optional
import time


@dataclass
class Signal:
    asset: str
    direction: Literal["LONG", "SHORT", "FLAT"]
    edge: float
    price: float
    strategy: str
    timeframe: str
    reason: str = ""
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    timestamp: float = field(default_factory=time.time)
    extras: dict = field(default_factory=dict)

    @property
    def is_actionable(self):
        return self.direction != "FLAT" and self.edge > 0

    def to_dict(self):
        return {
            "asset": self.asset,
            "direction": self.direction,
            "edge": round(self.edge, 1),
            "price": self.price,
            "strategy": self.strategy,
            "timeframe": self.timeframe,
            "reason": self.reason,
            "stop_loss": self.stop_loss,
            "take_profit": self.take_profit,
            "timestamp": self.timestamp,
        }
