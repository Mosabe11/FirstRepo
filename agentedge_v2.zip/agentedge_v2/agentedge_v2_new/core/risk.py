"""
core/risk.py — Risk gatekeeper
"""
import time
import threading
from datetime import datetime, timezone, timedelta
from config import settings


def _start_of_today_utc():
    now = datetime.now(timezone.utc)
    return datetime(now.year, now.month, now.day, tzinfo=timezone.utc).timestamp()


def _start_of_week_utc():
    now = datetime.now(timezone.utc)
    monday = now - timedelta(days=now.weekday())
    return datetime(monday.year, monday.month, monday.day, tzinfo=timezone.utc).timestamp()


class RiskManager:
    def __init__(self):
        self.daily_pnl = 0.0
        self.weekly_pnl = 0.0
        self.daily_anchor = _start_of_today_utc()
        self.weekly_anchor = _start_of_week_utc()
        self.last_trade_per_asset = {}
        self.last_trades_global = []
        self.blocked = False
        self.block_reason = ""
        self._lock = threading.Lock()

    def _rollover(self):
        now = time.time()
        if now >= self.daily_anchor + 86400:
            self.daily_pnl = 0.0
            self.daily_anchor = _start_of_today_utc()
            self.blocked = False
            self.block_reason = ""
        if now >= self.weekly_anchor + 7 * 86400:
            self.weekly_pnl = 0.0
            self.weekly_anchor = _start_of_week_utc()

    def pre_trade_check(self, asset, open_positions, has_position):
        with self._lock:
            self._rollover()
            if self.blocked:
                return False, f"Blocked: {self.block_reason}"
            if len(open_positions) >= settings.MAX_POSITIONS:
                return False, f"Max positions ({settings.MAX_POSITIONS})"
            if has_position:
                return False, f"Already have position on {asset}"
            if self.daily_pnl <= -abs(settings.DAILY_LIMIT):
                self.blocked = True
                self.block_reason = "daily limit hit"
                return False, self.block_reason
            if self.weekly_pnl <= -abs(settings.WEEKLY_LIMIT):
                self.blocked = True
                self.block_reason = "weekly limit hit"
                return False, self.block_reason
            now = time.time()
            last = self.last_trade_per_asset.get(asset, 0)
            cd = (settings.TRIGGER_COOLDOWN_IF_OPEN if has_position
                  else settings.TRIGGER_COOLDOWN_AFTER_TRADE)
            if now - last < cd:
                return False, f"Cooldown on {asset}"
            self.last_trades_global = [t for t in self.last_trades_global if now - t < 3600]
            if len(self.last_trades_global) >= settings.MAX_TRADES_PER_HOUR:
                return False, "Hourly limit reached"
            return True, "OK"

    def record_trade_opened(self, asset):
        with self._lock:
            now = time.time()
            self.last_trade_per_asset[asset] = now
            self.last_trades_global.append(now)

    def record_trade_closed(self, pnl):
        with self._lock:
            self._rollover()
            self.daily_pnl += pnl
            self.weekly_pnl += pnl

    def position_size(self, base_qty, edge, win_rate=0.5):
        edge_factor = max(0.5, min(1.5, edge / 70.0))
        wr_factor = max(0.7, min(1.3, win_rate / 0.5))
        return round(base_qty * edge_factor * wr_factor, 8)

    def snapshot(self):
        with self._lock:
            self._rollover()
            return {
                "daily_pnl": round(self.daily_pnl, 2),
                "weekly_pnl": round(self.weekly_pnl, 2),
                "daily_limit": settings.DAILY_LIMIT,
                "weekly_limit": settings.WEEKLY_LIMIT,
                "blocked": self.blocked,
                "block_reason": self.block_reason,
                "trades_last_hour": len(self.last_trades_global),
            }


risk_manager = RiskManager()
