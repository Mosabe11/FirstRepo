"""
core/ai_confirm.py — DeepSeek BUY/SELL/HOLD confirmation with Telegram notification
"""
import time
import json
import logging
import threading
import requests

from config import settings
from core.notify import tg_send

logger = logging.getLogger(__name__)
_cache = {}
_cache_lock = threading.Lock()
_API_URL = "https://api.deepseek.com/v1/chat/completions"


def _cache_get(key):
    with _cache_lock:
        if key in _cache:
            ts, val = _cache[key]
            if time.time() - ts < settings.AI_CACHE_TTL_SECONDS:
                return val
            del _cache[key]
    return None


def _cache_put(key, val):
    with _cache_lock:
        _cache[key] = (time.time(), val)


def confirm_trade(asset, direction, price, indicators):
    """
    Ask DeepSeek to confirm a proposed LONG/SHORT.
    Returns (decision, confidence_0_100).
    """
    if not settings.DEEPSEEK_KEY:
        return None, 0.0

    px_bucket = round(price * 100) / 100 if price < 100 else round(price)
    key = f"{asset}:{direction}:{px_bucket}"
    cached = _cache_get(key)
    if cached:
        return cached

    snap = {}
    for k in ["rsi", "macd_hist", "ema9", "ema21", "ema50",
              "bb_upper", "bb_lower", "vwap", "atr"]:
        v = indicators.get(k)
        if v is None:
            continue
        try:
            v_last = v[-1] if hasattr(v, "__len__") else v
            snap[k] = round(float(v_last), 6)
        except Exception:
            pass

    prompt = (
        f"Asset: {asset}\nDirection: {direction}\nPrice: {price}\n"
        f"Indicators: {json.dumps(snap)}\n\n"
        f"Should we execute this trade now? Respond with JSON only."
    )

    try:
        r = requests.post(
            _API_URL,
            headers={
                "Authorization": f"Bearer {settings.DEEPSEEK_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": "deepseek-chat",
                "messages": [
                    {"role": "system", "content":
                        "You are a disciplined trading risk reviewer. Respond ONLY with valid JSON: "
                        '{"decision":"BUY|SELL|HOLD","confidence":0-100,"reason":"..."}'},
                    {"role": "user", "content": prompt},
                ],
                "temperature": 0.2,
                "max_tokens": 200,
            },
            timeout=12,
        )
        if r.status_code != 200:
            logger.warning(f"DeepSeek HTTP {r.status_code}")
            return None, 0.0
        content = r.json()["choices"][0]["message"]["content"].strip()
        if content.startswith("```"):
            content = content.strip("`").lstrip("json").strip()
        data = json.loads(content)
        decision = str(data.get("decision", "HOLD")).upper()
        confidence = float(data.get("confidence", 0))
        if decision not in ("BUY", "SELL", "HOLD"):
            decision = "HOLD"
        result = (decision, confidence)
        _cache_put(key, result)

        # Telegram notification
        emoji = "🟢" if decision == "BUY" else "🔴" if decision == "SELL" else "⚪"
        reason = str(data.get("reason", ""))[:200]
        tg_send(
            f"{emoji} *AI Analysis* `{asset}`\n"
            f"Direction: {direction}\n"
            f"Decision: *{decision}*\n"
            f"Confidence: {confidence:.0f}%\n"
            f"Reason: {reason}",
            category="ai",
        )
        return result
    except Exception as e:
        logger.warning(f"DeepSeek call failed: {e}")
        return None, 0.0
