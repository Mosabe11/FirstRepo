"""
core/notify.py — Centralized Telegram notification helper.
All bots use _tg() from here to send notifications.
This avoids the import-name-collision bug we saw with `settings`.
"""
import logging
import requests

logger = logging.getLogger(__name__)


def tg_send(message: str, category: str = "general"):
    """
    Send a Telegram message. category controls which NOTIFY_* flag gates it.
    Categories: pulse, ai, open_close, discovery, cleaner, signal, general
    """
    from config import settings

    # Filter by category
    enabled = {
        "pulse": settings.NOTIFY_PULSE,
        "ai": settings.NOTIFY_AI,
        "open_close": settings.NOTIFY_OPEN_CLOSE,
        "discovery": settings.NOTIFY_DISCOVERY,
        "cleaner": settings.NOTIFY_CLEANER,
        "signal": settings.NOTIFY_SIGNAL,
        "general": True,
    }
    if not enabled.get(category, True):
        return

    if not settings.TELEGRAM_TOKEN or not settings.TELEGRAM_CHAT_ID:
        return

    try:
        requests.post(
            f"https://api.telegram.org/bot{settings.TELEGRAM_TOKEN}/sendMessage",
            json={
                "chat_id": settings.TELEGRAM_CHAT_ID,
                "text": message,
                "parse_mode": "Markdown",
                "disable_web_page_preview": True,
            },
            timeout=5,
        )
    except Exception as e:
        logger.warning(f"Telegram send failed: {e}")
