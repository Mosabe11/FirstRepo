"""
core/indicators.py — All technical indicators
"""
import numpy as np


def sma(values, period):
    out = np.full_like(values, np.nan, dtype=float)
    if len(values) < period:
        return out
    cumsum = np.cumsum(np.insert(values, 0, 0.0))
    out[period-1:] = (cumsum[period:] - cumsum[:-period]) / period
    return out


def ema(values, period):
    values = np.asarray(values, dtype=float)
    out = np.full_like(values, np.nan, dtype=float)
    if len(values) < period:
        return out
    alpha = 2.0 / (period + 1.0)
    out[period-1] = values[:period].mean()
    for i in range(period, len(values)):
        out[i] = alpha * values[i] + (1 - alpha) * out[i-1]
    return out


def alma(values, period=9, offset=0.85, sigma=6.0):
    values = np.asarray(values, dtype=float)
    out = np.full_like(values, np.nan, dtype=float)
    if len(values) < period:
        return out
    m = offset * (period - 1)
    s = period / sigma
    weights = np.array([np.exp(-((i-m)**2)/(2*s*s)) for i in range(period)])
    weights /= weights.sum()
    for i in range(period-1, len(values)):
        out[i] = np.dot(values[i-period+1:i+1], weights)
    return out


def rsi(values, period=14):
    values = np.asarray(values, dtype=float)
    out = np.full_like(values, np.nan, dtype=float)
    if len(values) < period + 1:
        return out
    deltas = np.diff(values)
    gains = np.where(deltas > 0, deltas, 0.0)
    losses = np.where(deltas < 0, -deltas, 0.0)
    avg_gain = gains[:period].mean()
    avg_loss = losses[:period].mean()
    if avg_loss == 0:
        out[period] = 100.0
    else:
        out[period] = 100 - (100 / (1 + avg_gain/avg_loss))
    for i in range(period+1, len(values)):
        avg_gain = (avg_gain*(period-1) + gains[i-1]) / period
        avg_loss = (avg_loss*(period-1) + losses[i-1]) / period
        if avg_loss == 0:
            out[i] = 100.0
        else:
            out[i] = 100 - (100 / (1 + avg_gain/avg_loss))
    return out


def macd(values, fast=12, slow=26, signal=9):
    macd_line = ema(values, fast) - ema(values, slow)
    signal_line = np.full_like(macd_line, np.nan)
    first_valid = np.argmax(~np.isnan(macd_line))
    if first_valid + signal < len(macd_line):
        signal_line[first_valid:] = ema(macd_line[first_valid:], signal)
    return macd_line, signal_line, macd_line - signal_line


def stochastic(high, low, close, k_period=14, d_period=3):
    high = np.asarray(high, dtype=float)
    low = np.asarray(low, dtype=float)
    close = np.asarray(close, dtype=float)
    n = len(close)
    k = np.full(n, np.nan)
    for i in range(k_period-1, n):
        wh = high[i-k_period+1:i+1].max()
        wl = low[i-k_period+1:i+1].min()
        rng = wh - wl
        k[i] = 50.0 if rng == 0 else 100*(close[i]-wl)/rng
    return k, sma(k, d_period)


def true_range(high, low, close):
    high = np.asarray(high, dtype=float)
    low = np.asarray(low, dtype=float)
    close = np.asarray(close, dtype=float)
    prev_close = np.roll(close, 1)
    prev_close[0] = close[0]
    return np.maximum.reduce([high-low, np.abs(high-prev_close), np.abs(low-prev_close)])


def atr(high, low, close, period=14):
    tr = true_range(high, low, close)
    out = np.full_like(tr, np.nan)
    if len(tr) < period:
        return out
    out[period-1] = tr[:period].mean()
    for i in range(period, len(tr)):
        out[i] = (out[i-1]*(period-1) + tr[i]) / period
    return out


def bollinger_bands(values, period=20, std_mult=2.0):
    values = np.asarray(values, dtype=float)
    middle = sma(values, period)
    out_upper = np.full_like(values, np.nan)
    out_lower = np.full_like(values, np.nan)
    for i in range(period-1, len(values)):
        sd = values[i-period+1:i+1].std(ddof=0)
        out_upper[i] = middle[i] + std_mult*sd
        out_lower[i] = middle[i] - std_mult*sd
    return out_upper, middle, out_lower


def keltner_channels(high, low, close, ema_period=20, atr_period=10, atr_mult=2.0):
    middle = ema(close, ema_period)
    atr_vals = atr(high, low, close, atr_period)
    return middle + atr_mult*atr_vals, middle, middle - atr_mult*atr_vals


def vwap(high, low, close, volume):
    typical = (np.asarray(high, dtype=float) + np.asarray(low, dtype=float)
               + np.asarray(close, dtype=float)) / 3.0
    pv = typical * np.asarray(volume, dtype=float)
    cum_v = np.cumsum(np.asarray(volume, dtype=float))
    return np.divide(np.cumsum(pv), cum_v, out=np.full_like(pv, np.nan), where=cum_v != 0)


def compute_all(candles):
    if not candles or len(candles) < 30:
        return {}
    arr = np.array(candles, dtype=float)
    high, low, close, vol = arr[:, 2], arr[:, 3], arr[:, 4], arr[:, 5]
    macd_line, macd_sig, macd_hist = macd(close)
    bb_up, bb_mid, bb_low = bollinger_bands(close)
    kc_up, kc_mid, kc_low = keltner_channels(high, low, close)
    stoch_k, stoch_d = stochastic(high, low, close)
    return {
        "close": close, "high": high, "low": low, "volume": vol,
        "ema9": ema(close, 9), "ema21": ema(close, 21), "ema50": ema(close, 50),
        "rsi": rsi(close, 14),
        "macd": macd_line, "macd_signal": macd_sig, "macd_hist": macd_hist,
        "bb_upper": bb_up, "bb_middle": bb_mid, "bb_lower": bb_low,
        "kc_upper": kc_up, "kc_middle": kc_mid, "kc_lower": kc_low,
        "atr": atr(high, low, close, 14),
        "vwap": vwap(high, low, close, vol),
        "alma": alma(close, 9),
        "stoch_k": stoch_k, "stoch_d": stoch_d,
        "vol_sma": sma(vol, 20),
    }
