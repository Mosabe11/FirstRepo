"""
core/market_data.py — MEXC + Binance + Yahoo (metals, forex)
"""
import time
import logging
import threading
from typing import Optional

import ccxt
import yfinance as yf
import pandas as pd

logger = logging.getLogger(__name__)


# ===== MEXC =====
_mexc_lock = threading.Lock()
_mexc: Optional[ccxt.mexc] = None


def get_mexc():
    global _mexc
    with _mexc_lock:
        if _mexc is None:
            _mexc = ccxt.mexc({"enableRateLimit": True, "timeout": 15000})
        return _mexc


def reconnect_mexc():
    global _mexc
    with _mexc_lock:
        _mexc = None
    return get_mexc()


# ===== Binance =====
_binance_lock = threading.Lock()
_binance: Optional[ccxt.binance] = None


def get_binance():
    global _binance
    with _binance_lock:
        if _binance is None:
            _binance = ccxt.binance({"enableRateLimit": True, "timeout": 15000})
        return _binance


def reconnect_binance():
    global _binance
    with _binance_lock:
        _binance = None
    return get_binance()


# ===== TTL Cache =====
class _TTLCache:
    def __init__(self, ttl=30.0):
        self.ttl = ttl
        self._data = {}
        self._lock = threading.Lock()

    def get(self, key):
        with self._lock:
            if key in self._data:
                ts, val = self._data[key]
                if time.time() - ts < self.ttl:
                    return val
        return None

    def set(self, key, val):
        with self._lock:
            self._data[key] = (time.time(), val)


_ohlcv_cache = _TTLCache(ttl=25)
_ticker_cache = _TTLCache(ttl=3)


# ===== Public API =====
def fetch_ohlcv(asset_class, exchange_symbol, timeframe="1h", limit=100):
    key = f"ohlcv:{asset_class}:{exchange_symbol}:{timeframe}:{limit}"
    cached = _ohlcv_cache.get(key)
    if cached is not None:
        return cached

    try:
        if asset_class == "crypto":
            data = _fetch_mexc_ohlcv(exchange_symbol, timeframe, limit)
        elif asset_class == "binance":
            data = _fetch_binance_ohlcv(exchange_symbol, timeframe, limit)
        elif asset_class in ("metal", "forex"):
            data = _fetch_yahoo_ohlcv(exchange_symbol, timeframe, limit)
        else:
            return []
        if data:
            _ohlcv_cache.set(key, data)
        return data
    except Exception as e:
        logger.warning(f"fetch_ohlcv failed {exchange_symbol}: {e}")
        return []


def fetch_price(asset_class, exchange_symbol):
    key = f"px:{asset_class}:{exchange_symbol}"
    cached = _ticker_cache.get(key)
    if cached is not None:
        return cached

    try:
        if asset_class == "crypto":
            ticker = get_mexc().fetch_ticker(exchange_symbol)
            price = float(ticker["last"])
        elif asset_class == "binance":
            ticker = get_binance().fetch_ticker(exchange_symbol)
            price = float(ticker["last"])
        elif asset_class in ("metal", "forex"):
            candles = _fetch_yahoo_ohlcv(exchange_symbol, "5m", 2)
            if not candles:
                # fallback to 1h
                candles = _fetch_yahoo_ohlcv(exchange_symbol, "1h", 2)
            if not candles:
                return None
            price = float(candles[-1][4])
        else:
            return None
        _ticker_cache.set(key, price)
        return price
    except Exception as e:
        logger.warning(f"fetch_price failed {exchange_symbol}: {e}")
        return None


def fetch_top_usdt_pairs_mexc(top_n=50, min_volume_usdt=1_000_000):
    """For Discovery on MEXC."""
    try:
        tickers = get_mexc().fetch_tickers()
    except Exception as e:
        logger.warning(f"MEXC fetch_tickers failed: {e}")
        return []
    candidates = []
    for sym, t in tickers.items():
        if not sym.endswith("/USDT"):
            continue
        qv = t.get("quoteVolume") or 0
        if qv < min_volume_usdt:
            continue
        candidates.append({
            "symbol": sym.split("/")[0],
            "exchange_symbol": sym,
            "quote_volume": qv,
            "percent_change": t.get("percentage", 0) or 0,
            "last": t.get("last", 0) or 0,
            "source": "MEXC",
        })
    candidates.sort(key=lambda x: x["quote_volume"], reverse=True)
    return candidates[:top_n]


def fetch_top_usdt_pairs_binance(top_n=50, min_volume_usdt=5_000_000):
    """For Discovery on Binance."""
    try:
        tickers = get_binance().fetch_tickers()
    except Exception as e:
        logger.warning(f"Binance fetch_tickers failed: {e}")
        return []
    candidates = []
    for sym, t in tickers.items():
        if not sym.endswith("/USDT"):
            continue
        qv = t.get("quoteVolume") or 0
        if qv < min_volume_usdt:
            continue
        candidates.append({
            "symbol": sym.split("/")[0],
            "exchange_symbol": sym,
            "quote_volume": qv,
            "percent_change": t.get("percentage", 0) or 0,
            "last": t.get("last", 0) or 0,
            "source": "Binance",
        })
    candidates.sort(key=lambda x: x["quote_volume"], reverse=True)
    return candidates[:top_n]


# Backwards compat alias
def fetch_top_usdt_pairs(top_n=50, min_volume_usdt=1_000_000):
    return fetch_top_usdt_pairs_mexc(top_n, min_volume_usdt)


# ===== Internals =====
def _fetch_mexc_ohlcv(symbol, timeframe, limit):
    try:
        return get_mexc().fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    except (ccxt.NetworkError, ccxt.ExchangeError) as e:
        logger.warning(f"MEXC error {symbol}, reconnecting: {e}")
        reconnect_mexc()
        try:
            return get_mexc().fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
        except Exception as e2:
            logger.error(f"MEXC retry failed {symbol}: {e2}")
            return []


def _fetch_binance_ohlcv(symbol, timeframe, limit):
    try:
        return get_binance().fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
    except (ccxt.NetworkError, ccxt.ExchangeError) as e:
        logger.warning(f"Binance error {symbol}, reconnecting: {e}")
        reconnect_binance()
        try:
            return get_binance().fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
        except Exception as e2:
            logger.error(f"Binance retry failed {symbol}: {e2}")
            return []


_YF_INTERVAL = {"1m": "1m", "5m": "5m", "15m": "15m", "1h": "60m", "1d": "1d"}
_YF_PERIOD = {"1m": "1d", "5m": "5d", "15m": "5d", "1h": "60d", "1d": "1y"}


def _fetch_yahoo_ohlcv(ticker, timeframe, limit):
    """Yahoo with MultiIndex columns fix (yfinance >= 0.2.40)."""
    try:
        df = yf.download(
            ticker,
            interval=_YF_INTERVAL.get(timeframe, "60m"),
            period=_YF_PERIOD.get(timeframe, "60d"),
            progress=False,
            auto_adjust=False,
        )
        if df is None or df.empty:
            return []
        # flatten MultiIndex columns (Yahoo's new default)
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = [col[0] for col in df.columns]
        df = df.tail(limit).reset_index()
        result = []
        for _, row in df.iterrows():
            try:
                ts = row.iloc[0]
                result.append([
                    int(ts.timestamp() * 1000),
                    float(row["Open"]),
                    float(row["High"]),
                    float(row["Low"]),
                    float(row["Close"]),
                    float(row.get("Volume", 0) or 0),
                ])
            except Exception:
                pass
        return result
    except Exception as e:
        logger.warning(f"Yahoo fetch failed {ticker}: {e}")
        return []
