"""
api/telegram.py — Telegram command listener
"""
import time
import logging
import threading
import requests

from config import settings
from core.signal import Signal
from execution.manager import position_manager
from execution import router
from core.risk import risk_manager
from core import market_data
from core.indicators import compute_all
from core.notify import tg_send
from storage.watchlist_runtime import registry

logger = logging.getLogger(__name__)
_API = "https://api.telegram.org/bot"


class TelegramBot:
    name = "telegram"

    def __init__(self, shutdown_event):
        self._stop = threading.Event()
        self._shutdown = shutdown_event
        self._offset = 0

    def stop(self):
        self._stop.set()

    def enabled(self):
        return bool(settings.TELEGRAM_TOKEN and settings.TELEGRAM_CHAT_ID)

    def run(self):
        if not self.enabled():
            logger.info("Telegram not configured — listener disabled")
            return
        logger.info("Telegram listener started")
        tg_send(f"🤖 AgentEdge v2 online — `{router.mode_label()}` mode", category="general")
        while not self._stop.is_set():
            try:
                self._poll_once()
            except Exception as e:
                logger.warning(f"Telegram poll error: {e}")
                self._stop.wait(5)
        logger.info("Telegram listener stopped")

    def _poll_once(self):
        try:
            r = requests.get(
                f"{_API}{settings.TELEGRAM_TOKEN}/getUpdates",
                params={"offset": self._offset, "timeout": 25},
                timeout=30,
            )
            if r.status_code != 200:
                self._stop.wait(3)
                return
            updates = r.json().get("result", [])
        except requests.RequestException:
            self._stop.wait(3)
            return

        for u in updates:
            self._offset = u["update_id"] + 1
            msg = u.get("message") or u.get("edited_message")
            if not msg:
                continue
            chat_id = str(msg.get("chat", {}).get("id"))
            if chat_id != str(settings.TELEGRAM_CHAT_ID):
                continue
            text = (msg.get("text") or "").strip()
            if not text:
                continue
            try:
                self._handle(text)
            except Exception as e:
                logger.exception(f"Telegram handler error: {e}")
                tg_send(f"⚠ error: {e}", category="general")

    def _handle(self, text):
        lower = text.lower()
        if lower in ("stop", "/stop"):
            tg_send("Shutting down...", category="general")
            self._shutdown.set()
            return
        if lower.startswith("/status"):
            return self._cmd_status()
        if lower.startswith("/watchlist"):
            return self._cmd_watchlist()
        if lower.startswith("/closeall"):
            return self._cmd_closeall()
        if lower.startswith("/close "):
            return self._cmd_close(text.split(maxsplit=1)[1].strip().upper())
        if lower.startswith("/signal "):
            return self._cmd_signal(text.split(maxsplit=2)[1:])
        if lower.startswith("/reset"):
            return self._cmd_reset()
        if lower.startswith("/help"):
            return self._cmd_help()
        if lower.startswith("/"):
            return tg_send("Unknown. Try /status /watchlist /closeall /help", category="general")
        self._cmd_quick_analysis(text.strip().upper())

    def _cmd_help(self):
        tg_send(
            "*Commands*\n"
            "/status — open positions & stats\n"
            "/watchlist — current assets\n"
            "/closeall — close all positions\n"
            "/close ASSET — close one\n"
            "/signal ASSET LONG|SHORT — manual trade\n"
            "/reset — wipe paper stats (paper only)\n"
            "STOP — graceful shutdown\n"
            "Or just type an asset name (e.g. `BTC`)",
            category="general",
        )

    def _cmd_status(self):
        stats = position_manager.stats()
        rstats = risk_manager.snapshot()
        positions = position_manager.open_positions()
        lines = [
            f"*Mode:* {stats['mode']}",
            f"*Win rate:* {stats['win_rate']}% ({stats['wins']}/{stats['total_trades']})",
            f"*Total PnL:* {stats['total_pnl']}",
            f"*Daily PnL:* {rstats['daily_pnl']} / -{rstats['daily_limit']}",
            f"*Open:* {len(positions)} positions",
        ]
        for p in positions:
            cfg = registry.get(p.asset)
            if cfg:
                price = market_data.fetch_price(cfg.asset_class, cfg.exchange_symbol) or p.entry_price
            else:
                price = p.entry_price
            lines.append(
                f"  `{p.asset}` {p.direction} qty={p.quantity} "
                f"now={price:.4f} pnl={p.pnl(price):+.4f}"
            )
        tg_send("\n".join(lines), category="general")

    def _cmd_watchlist(self):
        items = registry.all()
        # group by asset class
        by_class = {}
        for a in items:
            by_class.setdefault(a.asset_class, []).append(a.symbol)
        lines = [f"*Watchlist* ({len(items)} total):"]
        for cls in ("crypto", "binance", "metal", "forex"):
            if cls in by_class:
                lines.append(f"*{cls}:* {', '.join(by_class[cls])}")
        tg_send("\n".join(lines), category="general")

    def _cmd_closeall(self):
        results = position_manager.close_all(reason="telegram /closeall")
        tg_send(f"Close-all: {len(results)} positions processed", category="general")

    def _cmd_close(self, asset):
        for p in position_manager.open_positions():
            if p.asset == asset:
                ok, msg = position_manager.close_position(p.id, "telegram /close")
                tg_send(f"{asset}: {msg}", category="general")
                return
        tg_send(f"No open position on {asset}", category="general")

    def _cmd_signal(self, args):
        if not args:
            return tg_send("Usage: /signal ASSET LONG|SHORT", category="general")
        asset_name = args[0].upper()
        direction = (args[1] if len(args) > 1 else "LONG").upper()
        cfg = registry.get(asset_name)
        if not cfg:
            return tg_send(f"{asset_name} not in watchlist", category="general")
        price = market_data.fetch_price(cfg.asset_class, cfg.exchange_symbol)
        if not price:
            return tg_send(f"Could not fetch price for {asset_name}", category="general")
        sig = Signal(asset=asset_name, direction=direction, edge=80.0,
                     price=price, strategy="manual", timeframe="manual",
                     reason="manual /signal")
        ok, msg = position_manager.try_open(sig, cfg, use_ai=False)
        tg_send(f"Manual {asset_name} {direction}: {msg}", category="general")

    def _cmd_reset(self):
        if router.is_live():
            return tg_send("❌ /reset refused in LIVE mode", category="general")
        ok = position_manager.reset_paper()
        tg_send("✅ Paper stats reset" if ok else "❌ reset failed", category="general")

    def _cmd_quick_analysis(self, asset):
        cfg = registry.get(asset)
        if not cfg:
            return tg_send(f"{asset} not in watchlist", category="general")
        candles = market_data.fetch_ohlcv(cfg.asset_class, cfg.exchange_symbol, "1h", 80)
        if not candles:
            return tg_send(f"No data for {asset}", category="general")
        ind = compute_all(candles)
        if not ind:
            return tg_send(f"Indicators not ready for {asset}", category="general")
        tg_send(
            f"*{asset}* @ {ind['close'][-1]:.4f}\n"
            f"RSI: {ind['rsi'][-1]:.1f}\n"
            f"MACD hist: {ind['macd_hist'][-1]:.4f}\n"
            f"EMA9/21/50: {ind['ema9'][-1]:.4f} / {ind['ema21'][-1]:.4f} / {ind['ema50'][-1]:.4f}\n"
            f"BB: [{ind['bb_lower'][-1]:.4f}, {ind['bb_upper'][-1]:.4f}]\n"
            f"VWAP: {ind['vwap'][-1]:.4f}",
            category="general",
        )
