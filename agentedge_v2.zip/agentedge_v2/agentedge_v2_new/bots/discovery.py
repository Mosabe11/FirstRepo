"""
bots/discovery.py — Finds trending pairs on MEXC and Binance.

Trending score combines:
  - Volume spike
  - Price change % (1h and 24h)
  - Momentum (3 consecutive candles)
  - Strong directional move over 6h
"""
import logging
import threading

import numpy as np

from config import settings
from config.watchlist import AssetConfig
from core import market_data
from core.notify import tg_send
from storage.watchlist_runtime import registry

logger = logging.getLogger(__name__)


def _trending_score(exchange_symbol, asset_class):
    """0-100 trending score for a given pair."""
    try:
        candles = market_data.fetch_ohlcv(asset_class, exchange_symbol, "1h", 24)
        if not candles or len(candles) < 5:
            return 0
        arr = np.array(candles, dtype=float)
        close = arr[:, 4]
        vol = arr[:, 5]

        score = 0

        # 1h price change
        if close[-2] > 0:
            change_1h_pct = abs(close[-1] - close[-2]) / close[-2] * 100
            if change_1h_pct > 2:
                score += 30
            elif change_1h_pct > 1:
                score += 15

        # 24h price change
        if close[0] > 0:
            change_24h = abs(close[-1] - close[0]) / close[0] * 100
            if change_24h > 5:
                score += 20

        # Volume spike
        vol_avg = vol[:-1].mean()
        if vol_avg > 0 and vol[-1] > vol_avg * 1.5:
            score += 25

        # 3-bar momentum
        if close[-1] > close[-2] > close[-3]:
            score += 15
        elif close[-1] < close[-2] < close[-3]:
            score += 15

        # 6h directional move
        if len(close) >= 6:
            recent = close[-6:]
            if recent[-1] > recent[0] * 1.02 or recent[-1] < recent[0] * 0.98:
                score += 10

        return score
    except Exception as e:
        logger.debug(f"Trending score failed {exchange_symbol}: {e}")
        return 0


class DiscoveryBot:
    name = "discovery"

    # Curated Binance pool to scan (top liquid alts)
    BINANCE_POOL = [
        ("MATIC", "MATIC/USDT"), ("DOT", "DOT/USDT"),
        ("LINK", "LINK/USDT"), ("UNI", "UNI/USDT"),
        ("ATOM", "ATOM/USDT"), ("LTC", "LTC/USDT"),
        ("FIL", "FIL/USDT"), ("APT", "APT/USDT"),
        ("ARB", "ARB/USDT"), ("OP", "OP/USDT"),
        ("INJ", "INJ/USDT"), ("SUI", "SUI/USDT"),
        ("NEAR", "NEAR/USDT"), ("FET", "FET/USDT"),
    ]

    def __init__(self):
        self._stop = threading.Event()

    def stop(self):
        self._stop.set()

    def run(self):
        logger.info("Discovery bot started (MEXC + Binance trending)")
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception as e:
                logger.exception(f"Discovery tick error: {e}")
            self._stop.wait(settings.DISCOVERY_INTERVAL)
        logger.info("Discovery bot stopped")

    def _tick(self):
        if registry.size() >= settings.WATCHLIST_MAX_SIZE:
            return

        existing = {a.symbol for a in registry.all()}
        all_candidates = []

        # ===== MEXC =====
        try:
            mexc_pairs = market_data.fetch_top_usdt_pairs_mexc(
                top_n=40, min_volume_usdt=settings.DISCOVERY_MIN_VOLUME_USDT
            )
            for c in mexc_pairs:
                sym = c["symbol"]
                if sym in existing:
                    continue
                tscore = _trending_score(c["exchange_symbol"], "crypto")
                if tscore < 25:
                    continue
                vol_boost = min(20, c["quote_volume"] / 1e7)
                all_candidates.append({
                    "symbol": sym, "exchange_symbol": c["exchange_symbol"],
                    "asset_class": "crypto", "score": tscore + vol_boost,
                    "last": c.get("last", 1), "source": "MEXC",
                    "volume": c["quote_volume"],
                })
        except Exception as e:
            logger.warning(f"MEXC discovery failed: {e}")

        # ===== Binance — curated pool =====
        for sym, exsym in self.BINANCE_POOL:
            if self._stop.is_set():
                return
            if sym in existing:
                continue
            tscore = _trending_score(exsym, "binance")
            if tscore < 35:
                continue
            price = market_data.fetch_price("binance", exsym) or 1
            all_candidates.append({
                "symbol": sym, "exchange_symbol": exsym,
                "asset_class": "binance", "score": tscore,
                "last": price, "source": "Binance", "volume": 0,
            })

        if not all_candidates:
            return

        all_candidates.sort(reverse=True, key=lambda x: x["score"])

        added = 0
        for c in all_candidates[:settings.DISCOVERY_BATCH_SIZE]:
            if registry.size() >= settings.WATCHLIST_MAX_SIZE:
                break
            price = c["last"] or 1
            base_qty = max(0.0001, round(25.0 / price, 8))
            new_asset = AssetConfig(
                symbol=c["symbol"], exchange_symbol=c["exchange_symbol"],
                asset_class=c["asset_class"], base_qty=base_qty,
                tp_pct=0.015, sl_pct=0.008, is_base=False,
            )
            if registry.add(new_asset):
                added += 1
                logger.info(f"Discovery added {c['symbol']} from {c['source']} (score={c['score']:.1f})")
                tg_send(
                    f"🔍 *Discovery* Added `{c['symbol']}`\n"
                    f"Source: {c['source']}\n"
                    f"Trending score: {c['score']:.0f}\n"
                    f"Price: {price:.4f}",
                    category="discovery",
                )

        if added:
            logger.info(f"Discovery: +{added}, watchlist now {registry.size()}")
