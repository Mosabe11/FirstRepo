"""
bots/monitor.py — Watches open positions + emits market pulse every 5 min
"""
import time
import logging
import threading

from config import settings
from core import market_data
from core.notify import tg_send
from execution.manager import position_manager
from storage.watchlist_runtime import registry

logger = logging.getLogger(__name__)


class MonitorBot:
    name = "monitor"

    def __init__(self):
        self._stop = threading.Event()
        self._last_pulse = 0

    def stop(self):
        self._stop.set()

    def run(self):
        logger.info("Monitor bot started")
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception as e:
                logger.exception(f"Monitor tick error: {e}")
            self._stop.wait(settings.MONITOR_INTERVAL)
        logger.info("Monitor bot stopped")

    def _emit_pulse(self):
        now = time.time()
        if now - self._last_pulse < settings.PULSE_INTERVAL:
            return
        self._last_pulse = now
        from core.risk import risk_manager
        stats = position_manager.stats()
        risk = risk_manager.snapshot()
        wl = [a.symbol for a in registry.all()]
        msg = (
            f"📊 *Market Pulse*\n"
            f"Mode: {stats['mode']}\n"
            f"Open: {stats['open_positions']} positions\n"
            f"Win rate: {stats['win_rate']}% ({stats['wins']}W/{stats['losses']}L)\n"
            f"Total PnL: {stats['total_pnl']:+.2f}\n"
            f"Daily PnL: {risk['daily_pnl']:+.2f} / -{risk['daily_limit']}\n"
            f"Watchlist ({len(wl)}): {', '.join(wl[:12])}"
        )
        if len(wl) > 12:
            msg += f"... +{len(wl)-12}"
        tg_send(msg, category="pulse")

    def _tick(self):
        self._emit_pulse()
        positions = position_manager.open_positions()
        if not positions:
            return
        seen_prices = {}
        for pos in positions:
            cfg = registry.get(pos.asset)
            if not cfg:
                continue
            key = (cfg.asset_class, cfg.exchange_symbol)
            if key in seen_prices:
                price = seen_prices[key]
            else:
                price = market_data.fetch_price(cfg.asset_class, cfg.exchange_symbol)
                seen_prices[key] = price
            if price is None:
                continue
            outcome = pos.update(price)
            if outcome != "HOLD":
                position_manager.close_position(pos.id, reason=outcome)
