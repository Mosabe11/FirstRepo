"""
bots/trigger.py — High-frequency scalping bot with 3-stage pipeline:
  1. Pre-filter (no AI) — narrows down candidates by volume/momentum/ATR
  2. Strategy Evaluation — only on candidates that passed pre-filter
  3. AI Confirmation — only on the top signals
"""
import time
import logging
import threading
import numpy as np

from config import settings
from core import market_data
from core.notify import tg_send
from execution.manager import position_manager
from storage.watchlist_runtime import registry
from strategies import scalping_strategies

logger = logging.getLogger(__name__)


class TriggerBot:
    name = "trigger"

    def __init__(self):
        self._stop = threading.Event()
        self._candle_cache = {}

    def stop(self):
        self._stop.set()

    def run(self):
        if not scalping_strategies:
            logger.warning("No scalping strategies — trigger bot exiting")
            return
        logger.info(f"Trigger bot started ({len(scalping_strategies)} strategies, 3-stage pipeline)")
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception as e:
                logger.exception(f"Trigger tick error: {e}")
            self._stop.wait(settings.TRIGGER_INTERVAL)
        logger.info("Trigger bot stopped")

    def _get_candles(self, asset_class, exchange_symbol, timeframe, limit=80):
        key = (exchange_symbol, timeframe)
        now = time.time()
        ttl = 30 if timeframe == "1m" else 60
        cached = self._candle_cache.get(key)
        if cached and now - cached[0] < ttl:
            return cached[1]
        data = market_data.fetch_ohlcv(asset_class, exchange_symbol, timeframe, limit)
        if data:
            self._candle_cache[key] = (now, data)
        return data or []

    def _prefilter_score(self, cfg, candles):
        """Score 0-100 — bigger means more 'tradeable' right now."""
        if len(candles) < 20:
            return 0
        score = 0
        arr = np.array(candles, dtype=float)
        close = arr[:, 4]
        vol = arr[:, 5]

        # Volume spike
        vol_avg = vol[-20:-1].mean()
        if vol_avg > 0 and vol[-1] > vol_avg * 1.3:
            score += 25

        # Price momentum — 3 consecutive candles
        if close[-1] > close[-2] > close[-3]:
            score += 25
        elif close[-1] < close[-2] < close[-3]:
            score += 25

        # ATR sanity — neither dead nor crazy volatile
        highs = arr[:, 2]
        lows = arr[:, 3]
        atr = float(np.mean(highs[-14:] - lows[-14:]))
        atr_pct = atr / close[-1] if close[-1] > 0 else 0
        if 0.002 < atr_pct < 0.05:
            score += 25

        # No existing position
        if not position_manager.has_position_on(cfg.symbol):
            score += 25

        return score

    def _tick(self):
        assets = registry.all()
        candidates = []

        # ===== Stage 1: Pre-filter =====
        for cfg in assets:
            if self._stop.is_set():
                return
            candles = self._get_candles(cfg.asset_class, cfg.exchange_symbol, "5m")
            pre_score = self._prefilter_score(cfg, candles)
            if pre_score >= settings.PREFILTER_THRESHOLD:
                candidates.append((pre_score, cfg, candles))

        if not candidates:
            return
        candidates.sort(reverse=True, key=lambda x: x[0])
        logger.debug(f"Pre-filter: {len(candidates)} candidates from {len(assets)} assets")

        # ===== Stage 2: Strategy Evaluation =====
        signals = []
        for pre_score, cfg, candles_5m in candidates:
            for strat in scalping_strategies:
                if strat.timeframe == "5m":
                    cs = candles_5m
                else:
                    cs = self._get_candles(cfg.asset_class, cfg.exchange_symbol, strat.timeframe)
                if len(cs) < strat.min_candles:
                    continue
                try:
                    sig = strat.evaluate(cfg.symbol, cs)
                except Exception as e:
                    logger.warning(f"{strat.name} on {cfg.symbol}: {e}")
                    continue
                if not sig.is_actionable:
                    continue
                if sig.edge < settings.TRIGGER_EDGE:
                    continue
                signals.append((sig, cfg, pre_score))
                tg_send(
                    f"🔍 *Signal* `{cfg.symbol}`\n"
                    f"Strategy: {strat.name}\n"
                    f"Direction: {sig.direction}\n"
                    f"Edge: {sig.edge:.0f}\n"
                    f"Reason: {sig.reason}",
                    category="signal",
                )

        if not signals:
            return

        # Sort by edge — strongest first
        signals.sort(reverse=True, key=lambda x: x[0].edge)

        # ===== Stage 3: AI confirmation — only top 3 candidates =====
        for sig, cfg, pre_score in signals[:3]:
            ok, msg = position_manager.try_open(sig, cfg, use_ai=True)
            if ok:
                logger.info(f"[trigger] {cfg.symbol} {sig.direction} edge={sig.edge:.0f} → {msg}")
                break
            else:
                logger.debug(f"[trigger] {cfg.symbol} rejected: {msg}")
