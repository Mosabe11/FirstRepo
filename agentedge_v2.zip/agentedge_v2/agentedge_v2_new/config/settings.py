"""
config/settings.py — All runtime settings from .env
"""
import os
from pathlib import Path
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(PROJECT_ROOT / ".env")


def _bool(name, default):
    v = os.getenv(name, str(default)).strip().lower()
    return v in ("true", "1", "yes", "y", "on")


def _int(name, default):
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


def _float(name, default):
    try:
        return float(os.getenv(name, str(default)))
    except ValueError:
        return default


# Execution
LIVE_MODE = _bool("LIVE_MODE", False)

# API Keys
MEXC_API_KEY = os.getenv("MEXC_API_KEY", "")
MEXC_API_SECRET = os.getenv("MEXC_API_SECRET", "")
BINANCE_API_KEY = os.getenv("BINANCE_API_KEY", "")
BINANCE_API_SECRET = os.getenv("BINANCE_API_SECRET", "")
DEEPSEEK_KEY = os.getenv("DEEPSEEK_KEY", "")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# Network
HTTP_PORT = _int("HTTP_PORT", 8080)

# Risk
MAX_POSITIONS = _int("MAX_POSITIONS", 7)
DAILY_LIMIT = _float("DAILY_LIMIT", 800)
WEEKLY_LIMIT = _float("WEEKLY_LIMIT", 3000)
MAX_PRICE_DRIFT = _float("MAX_PRICE_DRIFT", 0.02)
PAPER_STARTING_BALANCE = _float("PAPER_STARTING_BALANCE", 10000)

DEFAULT_TP_PCT = 0.015
DEFAULT_SL_PCT = 0.008
BREAKEVEN_TRIGGER_PCT = 0.005
TRAILING_DISTANCE_PCT = 0.002
MAX_TRADES_PER_HOUR = 7
TRIGGER_COOLDOWN_AFTER_TRADE = 60
TRIGGER_COOLDOWN_IF_OPEN = 180

# Strategy toggles
ENABLE_SWING_1H = _bool("ENABLE_SWING_1H", True)
ENABLE_VWAP_MACD = _bool("ENABLE_VWAP_MACD", True)
ENABLE_KELTNER_RSI = _bool("ENABLE_KELTNER_RSI", True)
ENABLE_ALMA_STOCH = _bool("ENABLE_ALMA_STOCH", True)
ENABLE_RSI_BB_REVERT = _bool("ENABLE_RSI_BB_REVERT", True)

# Bot toggles
ENABLE_MONITOR = _bool("ENABLE_MONITOR", True)
ENABLE_TRIGGER = _bool("ENABLE_TRIGGER", True)
ENABLE_AUTO_SCANNER = _bool("ENABLE_AUTO_SCANNER", True)
ENABLE_DISCOVERY = _bool("ENABLE_DISCOVERY", True)
ENABLE_CLEANER = _bool("ENABLE_CLEANER", True)

# Intervals (seconds)
MONITOR_INTERVAL = 5
TRIGGER_INTERVAL = _int("TRIGGER_INTERVAL", 3)
AUTO_SCAN_INTERVAL = _int("AUTO_SCAN_INTERVAL", 120)
DISCOVERY_INTERVAL = _int("DISCOVERY_INTERVAL", 120)
CLEANER_INTERVAL = _int("CLEANER_INTERVAL", 300)

# Thresholds
TRIGGER_EDGE = _float("TRIGGER_EDGE", 65)
AUTO_ENTRY = _float("AUTO_ENTRY", 60)
AI_MIN_CONFIDENCE = _float("AI_MIN_CONFIDENCE", 60)
PREFILTER_THRESHOLD = _float("PREFILTER_THRESHOLD", 50)

# Notification toggles
NOTIFY_PULSE = _bool("NOTIFY_PULSE", True)
NOTIFY_AI = _bool("NOTIFY_AI", True)
NOTIFY_OPEN_CLOSE = _bool("NOTIFY_OPEN_CLOSE", True)
NOTIFY_DISCOVERY = _bool("NOTIFY_DISCOVERY", True)
NOTIFY_CLEANER = _bool("NOTIFY_CLEANER", True)
NOTIFY_SIGNAL = _bool("NOTIFY_SIGNAL", True)

# Watchlist
WATCHLIST_MAX_SIZE = 20
DISCOVERY_BATCH_SIZE = 5
DISCOVERY_MIN_VOLUME_USDT = 1_000_000

# Data
DATA_DIR = PROJECT_ROOT / "data"
LOGS_DIR = PROJECT_ROOT / "logs"
DATA_DIR.mkdir(exist_ok=True)
LOGS_DIR.mkdir(exist_ok=True)
LOG_RETENTION_DAYS = 7

# AI Cache
AI_CACHE_TTL_SECONDS = 300

# Pulse interval
PULSE_INTERVAL = 300  # 5 minutes


def validate():
    errors = []
    if not DEEPSEEK_KEY:
        errors.append("DEEPSEEK_KEY not set")
    if not TELEGRAM_TOKEN:
        errors.append("TELEGRAM_TOKEN not set")
    if LIVE_MODE and (not MEXC_API_KEY or not MEXC_API_SECRET):
        errors.append("LIVE_MODE=true but MEXC keys missing — REFUSING TO START LIVE")
    return errors


def summary():
    mode = "🔴 LIVE" if LIVE_MODE else "🟢 PAPER"
    return (
        f"\n{'='*60}\n"
        f"  AgentEdge v2.1 (Enhanced)  |  Mode: {mode}\n"
        f"  Dashboard: http://0.0.0.0:{HTTP_PORT}\n"
        f"  Max positions: {MAX_POSITIONS}  |  Daily limit: ${DAILY_LIMIT}\n"
        f"  Pre-filter: {PREFILTER_THRESHOLD}  |  Trigger edge: {TRIGGER_EDGE}\n"
        f"  AI min confidence: {AI_MIN_CONFIDENCE}\n"
        f"{'='*60}\n"
    )
