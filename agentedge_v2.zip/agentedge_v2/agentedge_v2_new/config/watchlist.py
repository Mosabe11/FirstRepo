"""
config/watchlist.py — Base watchlist + asset class definitions
"""
from dataclasses import dataclass


@dataclass
class AssetConfig:
    symbol: str
    exchange_symbol: str
    asset_class: str   # crypto | binance | metal | forex
    base_qty: float
    tp_pct: float = 0.015
    sl_pct: float = 0.008
    is_base: bool = True


BASE_WATCHLIST = [
    # MEXC crypto
    AssetConfig("BTC",    "BTC/USDT", "crypto",  base_qty=0.001),
    AssetConfig("ETH",    "ETH/USDT", "crypto",  base_qty=0.02),
    AssetConfig("XRP",    "XRP/USDT", "crypto",  base_qty=50),
    AssetConfig("SOL",    "SOL/USDT", "crypto",  base_qty=0.5),
    # Metals (Yahoo)
    AssetConfig("GOLD",   "GLD",      "metal",   base_qty=0.1,  tp_pct=0.008, sl_pct=0.004),
    AssetConfig("SILVER", "SLV",      "metal",   base_qty=1.0,  tp_pct=0.012, sl_pct=0.006),
]

FOREX_PAIRS = [
    AssetConfig("EURUSD", "EURUSD=X", "forex", base_qty=1000, tp_pct=0.005, sl_pct=0.003),
    AssetConfig("GBPUSD", "GBPUSD=X", "forex", base_qty=1000, tp_pct=0.005, sl_pct=0.003),
    AssetConfig("USDJPY", "USDJPY=X", "forex", base_qty=1000, tp_pct=0.005, sl_pct=0.003),
    AssetConfig("USDCHF", "USDCHF=X", "forex", base_qty=1000, tp_pct=0.005, sl_pct=0.003),
    AssetConfig("AUDUSD", "AUDUSD=X", "forex", base_qty=1000, tp_pct=0.005, sl_pct=0.003),
    AssetConfig("USDCAD", "USDCAD=X", "forex", base_qty=1000, tp_pct=0.005, sl_pct=0.003),
]

BINANCE_ASSETS = [
    AssetConfig("BNB",  "BNB/USDT",  "binance", base_qty=0.5),
    AssetConfig("DOGE", "DOGE/USDT", "binance", base_qty=500),
    AssetConfig("ADA",  "ADA/USDT",  "binance", base_qty=100),
    AssetConfig("AVAX", "AVAX/USDT", "binance", base_qty=1),
]

BASE_WATCHLIST_ALL = BASE_WATCHLIST + FOREX_PAIRS + BINANCE_ASSETS


def to_dict():
    return {a.symbol: a for a in BASE_WATCHLIST_ALL}
