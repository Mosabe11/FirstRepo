"""
storage/state.py — Atomic JSON state persistence
"""
import os
import json
import logging
import threading
from config import settings

logger = logging.getLogger(__name__)

STATE_PATH = settings.DATA_DIR / "state.json"
WATCHLIST_PATH = settings.DATA_DIR / "watchlist.json"

_lock = threading.Lock()


def load_state():
    if not STATE_PATH.exists():
        return {}
    try:
        with open(STATE_PATH, "r") as f:
            return json.load(f)
    except Exception as e:
        logger.warning(f"State load failed: {e}")
        return {}


def save_state(state):
    with _lock:
        tmp = STATE_PATH.with_suffix(".json.tmp")
        try:
            with open(tmp, "w") as f:
                json.dump(state, f, indent=2, default=str)
            os.replace(tmp, STATE_PATH)
        except Exception as e:
            logger.error(f"State save failed: {e}")


def load_watchlist():
    if not WATCHLIST_PATH.exists():
        return []
    try:
        with open(WATCHLIST_PATH, "r") as f:
            return json.load(f)
    except Exception:
        return []


def save_watchlist(assets):
    with _lock:
        tmp = WATCHLIST_PATH.with_suffix(".json.tmp")
        try:
            with open(tmp, "w") as f:
                json.dump(assets, f, indent=2, default=str)
            os.replace(tmp, WATCHLIST_PATH)
        except Exception as e:
            logger.error(f"Watchlist save failed: {e}")
