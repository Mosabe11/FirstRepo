"""
storage/watchlist_runtime.py — Runtime watchlist registry (thread-safe)
"""
import threading

from config.watchlist import BASE_WATCHLIST_ALL, AssetConfig


class WatchlistRegistry:
    def __init__(self):
        self._lock = threading.RLock()
        self._assets = {}
        for a in BASE_WATCHLIST_ALL:
            self._assets[a.symbol] = a

    def all(self):
        with self._lock:
            return list(self._assets.values())

    def crypto_only(self):
        with self._lock:
            return [a for a in self._assets.values() if a.asset_class in ("crypto", "binance")]

    def metals_only(self):
        with self._lock:
            return [a for a in self._assets.values() if a.asset_class == "metal"]

    def forex_only(self):
        with self._lock:
            return [a for a in self._assets.values() if a.asset_class == "forex"]

    def get(self, symbol):
        with self._lock:
            return self._assets.get(symbol)

    def add(self, asset):
        with self._lock:
            if asset.symbol in self._assets:
                return False
            self._assets[asset.symbol] = asset
            return True

    def remove(self, symbol):
        with self._lock:
            cfg = self._assets.get(symbol)
            if cfg is None or cfg.is_base:
                return False
            del self._assets[symbol]
            return True

    def size(self):
        with self._lock:
            return len(self._assets)


registry = WatchlistRegistry()
