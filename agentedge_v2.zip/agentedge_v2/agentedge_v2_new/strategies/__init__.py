"""
strategies/__init__.py — Registry of enabled strategies
"""
from config import settings
from strategies.swing_1h import Swing1hStrategy
from strategies.vwap_macd import VwapMacdStrategy
from strategies.keltner_rsi import KeltnerRsiStrategy
from strategies.alma_stoch import AlmaStochStrategy
from strategies.rsi_bb_revert import RsiBbRevertStrategy


def build_scalping_strategies():
    out = []
    if settings.ENABLE_VWAP_MACD: out.append(VwapMacdStrategy())
    if settings.ENABLE_KELTNER_RSI: out.append(KeltnerRsiStrategy())
    if settings.ENABLE_ALMA_STOCH: out.append(AlmaStochStrategy())
    if settings.ENABLE_RSI_BB_REVERT: out.append(RsiBbRevertStrategy())
    return out


def build_swing_strategies():
    out = []
    if settings.ENABLE_SWING_1H: out.append(Swing1hStrategy())
    return out


scalping_strategies = build_scalping_strategies()
swing_strategies = build_swing_strategies()
