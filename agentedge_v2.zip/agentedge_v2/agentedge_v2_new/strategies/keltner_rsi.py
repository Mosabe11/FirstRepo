"""
strategies/keltner_rsi.py — PDF strategy #2: Keltner + RSI reversal
"""
import numpy as np

from core.signal import Signal
from core.indicators import keltner_channels, rsi
from strategies.base import Strategy


class KeltnerRsiStrategy(Strategy):
    name = "keltner_rsi"
    timeframe = "5m"
    min_candles = 60

    def evaluate(self, asset, candles):
        if len(candles) < self.min_candles:
            return self._flat(asset, 0, self.name, self.timeframe, "not enough candles")
        arr = np.array(candles, dtype=float)
        high, low, close = arr[:, 2], arr[:, 3], arr[:, 4]
        price = float(close[-1])

        kc_up, kc_mid, kc_low = keltner_channels(high, low, close)
        rsi_arr = rsi(close, 14)

        if not (self._valid_last(kc_up, 2) and self._valid_last(kc_low, 2)
                and self._valid_last(rsi_arr, 2)):
            return self._flat(asset, price, self.name, self.timeframe, "not ready")

        two_below = close[-1] < kc_low[-1] and close[-2] < kc_low[-2]
        two_above = close[-1] > kc_up[-1] and close[-2] > kc_up[-2]
        rsi_up_50 = rsi_arr[-1] > 50 and rsi_arr[-2] <= 50
        rsi_dn_50 = rsi_arr[-1] < 50 and rsi_arr[-2] >= 50

        if two_below and rsi_arr[-1] > 50:
            return Signal(asset=asset, direction="LONG",
                          edge=self._score(rsi_arr, rsi_up_50, "long"),
                          price=price, strategy=self.name, timeframe=self.timeframe,
                          reason="2 closes below lower KC + RSI > 50",
                          stop_loss=float(kc_up[-1]), take_profit=float(kc_mid[-1]),
                          extras={"rsi": float(rsi_arr[-1])})

        if two_above and rsi_arr[-1] < 50:
            return Signal(asset=asset, direction="SHORT",
                          edge=self._score(rsi_arr, rsi_dn_50, "short"),
                          price=price, strategy=self.name, timeframe=self.timeframe,
                          reason="2 closes above upper KC + RSI < 50",
                          stop_loss=float(kc_low[-1]), take_profit=float(kc_mid[-1]),
                          extras={"rsi": float(rsi_arr[-1])})

        return self._flat(asset, price, self.name, self.timeframe, "no setup")

    def _score(self, rsi_arr, fresh_cross, side):
        edge = 60.0
        if fresh_cross:
            edge += 15
        latest = rsi_arr[-1]
        if side == "long":
            edge += min(15, max(0, latest - 50) * 0.6)
        else:
            edge += min(15, max(0, 50 - latest) * 0.6)
        return min(95, edge)
