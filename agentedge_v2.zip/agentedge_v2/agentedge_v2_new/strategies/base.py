"""
strategies/base.py — Abstract Strategy interface
"""
from abc import ABC, abstractmethod
import numpy as np

from core.signal import Signal


class Strategy(ABC):
    name: str = "base"
    timeframe: str = "1h"
    min_candles: int = 50

    @abstractmethod
    def evaluate(self, asset, candles):
        ...

    @staticmethod
    def _flat(asset, price, strategy, timeframe, reason=""):
        return Signal(
            asset=asset, direction="FLAT", edge=0.0,
            price=price, strategy=strategy, timeframe=timeframe,
            reason=reason,
        )

    @staticmethod
    def _valid_last(arr, k=1):
        if arr is None or len(arr) < k:
            return False
        return bool(np.all(np.isfinite(arr[-k:])))
