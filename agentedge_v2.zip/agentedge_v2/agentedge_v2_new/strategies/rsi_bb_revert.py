"""
strategies/rsi_bb_revert.py — PDF strategy #4: RSI + Bollinger Band reversion
"""
import numpy as np

from core.signal import Signal
from core.indicators import bollinger_bands, rsi
from strategies.base import Strategy


class RsiBbRevertStrategy(Strategy):
    name = "rsi_bb_revert"
    timeframe = "5m"
    min_candles = 40
    SL_BAND_BUFFER = 0.0015

    def evaluate(self, asset, candles):
        if len(candles) < self.min_candles:
            return self._flat(asset, 0, self.name, self.timeframe, "not enough candles")
        arr = np.array(candles, dtype=float)
        high, low, close = arr[:, 2], arr[:, 3], arr[:, 4]
        price = float(close[-1])

        bb_up, bb_mid, bb_low = bollinger_bands(close, 20, 2.0)
        rsi_arr = rsi(close, 14)

        if not (self._valid_last(bb_up, 2) and self._valid_last(bb_low, 2)
                and self._valid_last(rsi_arr, 2)):
            return self._flat(asset, price, self.name, self.timeframe, "not ready")

        touched_lower = low[-1] <= bb_low[-1] or close[-1] <= bb_low[-1]
        touched_upper = high[-1] >= bb_up[-1] or close[-1] >= bb_up[-1]
        rsi_up_30 = rsi_arr[-1] > 30 and rsi_arr[-2] <= 30
        rsi_dn_70 = rsi_arr[-1] < 70 and rsi_arr[-2] >= 70

        if touched_lower and rsi_up_30:
            sl = float(bb_low[-1]) * (1 - self.SL_BAND_BUFFER)
            sl = min(sl, float(low[-8:].min()))
            tp = float(bb_up[-1])
            return Signal(asset=asset, direction="LONG",
                          edge=self._score(rsi_arr, bb_low, close, "long"),
                          price=price, strategy=self.name, timeframe=self.timeframe,
                          reason="lower BB touched + RSI cross above 30",
                          stop_loss=sl, take_profit=tp,
                          extras={"rsi": float(rsi_arr[-1])})

        if touched_upper and rsi_dn_70:
            sl = float(bb_up[-1]) * (1 + self.SL_BAND_BUFFER)
            sl = max(sl, float(high[-8:].max()))
            tp = float(bb_low[-1])
            return Signal(asset=asset, direction="SHORT",
                          edge=self._score(rsi_arr, bb_up, close, "short"),
                          price=price, strategy=self.name, timeframe=self.timeframe,
                          reason="upper BB touched + RSI cross below 70",
                          stop_loss=sl, take_profit=tp,
                          extras={"rsi": float(rsi_arr[-1])})

        return self._flat(asset, price, self.name, self.timeframe, "no setup")

    def _score(self, rsi_arr, band, close, side):
        edge = 60.0
        if side == "long":
            recent_min = np.nanmin(rsi_arr[-5:])
            edge += min(20, max(0, 30 - recent_min) * 1.5)
            if close[-1] < band[-1]:
                edge += 8
        else:
            recent_max = np.nanmax(rsi_arr[-5:])
            edge += min(20, max(0, recent_max - 70) * 1.5)
            if close[-1] > band[-1]:
                edge += 8
        return min(95, edge)
