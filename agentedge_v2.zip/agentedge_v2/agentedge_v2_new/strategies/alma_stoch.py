"""
strategies/alma_stoch.py — PDF strategy #3: ALMA + Stochastic
"""
import numpy as np

from core.signal import Signal
from core.indicators import alma, stochastic
from strategies.base import Strategy


class AlmaStochStrategy(Strategy):
    name = "alma_stoch"
    timeframe = "1m"
    min_candles = 40
    SWING_LOOKBACK = 8
    RR_RATIO = 1.5

    def evaluate(self, asset, candles):
        if len(candles) < self.min_candles:
            return self._flat(asset, 0, self.name, self.timeframe, "not enough candles")
        arr = np.array(candles, dtype=float)
        high, low, close = arr[:, 2], arr[:, 3], arr[:, 4]
        price = float(close[-1])

        alma_arr = alma(close, period=9)
        k, d = stochastic(high, low, close, k_period=14, d_period=3)

        if not (self._valid_last(alma_arr, 2) and self._valid_last(k, 2)):
            return self._flat(asset, price, self.name, self.timeframe, "not ready")

        above = close[-1] > alma_arr[-1]
        below = close[-1] < alma_arr[-1]
        k_up_20 = k[-1] > 20 and k[-2] <= 20
        k_dn_80 = k[-1] < 80 and k[-2] >= 80

        swing_low = float(np.min(low[-self.SWING_LOOKBACK:]))
        swing_high = float(np.max(high[-self.SWING_LOOKBACK:]))

        if above and k_up_20:
            sl = swing_low
            risk = price - sl
            if risk <= 0:
                return self._flat(asset, price, self.name, self.timeframe, "invalid risk")
            tp = price + risk * self.RR_RATIO
            return Signal(asset=asset, direction="LONG",
                          edge=self._score(alma_arr, "long"),
                          price=price, strategy=self.name, timeframe=self.timeframe,
                          reason="above ALMA + Stoch cross above 20",
                          stop_loss=sl, take_profit=tp,
                          extras={"alma": float(alma_arr[-1]), "stoch_k": float(k[-1])})

        if below and k_dn_80:
            sl = swing_high
            risk = sl - price
            if risk <= 0:
                return self._flat(asset, price, self.name, self.timeframe, "invalid risk")
            tp = price - risk * self.RR_RATIO
            return Signal(asset=asset, direction="SHORT",
                          edge=self._score(alma_arr, "short"),
                          price=price, strategy=self.name, timeframe=self.timeframe,
                          reason="below ALMA + Stoch cross below 80",
                          stop_loss=sl, take_profit=tp,
                          extras={"alma": float(alma_arr[-1]), "stoch_k": float(k[-1])})

        return self._flat(asset, price, self.name, self.timeframe, "no setup")

    def _score(self, alma_arr, side):
        edge = 65.0
        if len(alma_arr) >= 5 and np.all(np.isfinite(alma_arr[-5:])):
            slope = alma_arr[-1] - alma_arr[-5]
            if (side == "long" and slope > 0) or (side == "short" and slope < 0):
                edge += min(15, abs(slope / alma_arr[-1]) * 5000)
        return min(95, edge)
