"""
strategies/vwap_macd.py — PDF strategy #1: VWAP + MACD Momentum
"""
import numpy as np

from core.signal import Signal
from core.indicators import vwap, macd
from strategies.base import Strategy


class VwapMacdStrategy(Strategy):
    name = "vwap_macd"
    timeframe = "5m"
    min_candles = 60
    SWING_LOOKBACK = 10
    RR_RATIO = 1.5

    def evaluate(self, asset, candles):
        if len(candles) < self.min_candles:
            return self._flat(asset, 0, self.name, self.timeframe, "not enough candles")

        arr = np.array(candles, dtype=float)
        high, low, close, vol = arr[:, 2], arr[:, 3], arr[:, 4], arr[:, 5]
        price = float(close[-1])

        vwap_arr = vwap(high, low, close, vol)
        macd_line, signal_line, hist = macd(close)

        if not (self._valid_last(vwap_arr, 2) and self._valid_last(macd_line, 2)
                and self._valid_last(signal_line, 2) and self._valid_last(hist, 1)):
            return self._flat(asset, price, self.name, self.timeframe, "indicators not ready")

        above_vwap = close[-1] > vwap_arr[-1]
        below_vwap = close[-1] < vwap_arr[-1]
        bull_cross = macd_line[-1] > signal_line[-1] and macd_line[-2] <= signal_line[-2]
        bear_cross = macd_line[-1] < signal_line[-1] and macd_line[-2] >= signal_line[-2]
        hist_pos = hist[-1] > 0
        hist_neg = hist[-1] < 0

        swing_low = float(np.min(low[-self.SWING_LOOKBACK:]))
        swing_high = float(np.max(high[-self.SWING_LOOKBACK:]))

        if above_vwap and bull_cross and hist_pos:
            sl = swing_low
            risk = price - sl
            if risk <= 0:
                return self._flat(asset, price, self.name, self.timeframe, "invalid risk")
            tp = price + risk * self.RR_RATIO
            edge = self._score(price, vwap_arr[-1], hist, "long")
            return Signal(asset=asset, direction="LONG", edge=edge, price=price,
                          strategy=self.name, timeframe=self.timeframe,
                          reason="price above VWAP, MACD bull cross, hist+",
                          stop_loss=sl, take_profit=tp,
                          extras={"vwap": float(vwap_arr[-1]), "macd_hist": float(hist[-1])})

        if below_vwap and bear_cross and hist_neg:
            sl = swing_high
            risk = sl - price
            if risk <= 0:
                return self._flat(asset, price, self.name, self.timeframe, "invalid risk")
            tp = price - risk * self.RR_RATIO
            edge = self._score(price, vwap_arr[-1], hist, "short")
            return Signal(asset=asset, direction="SHORT", edge=edge, price=price,
                          strategy=self.name, timeframe=self.timeframe,
                          reason="price below VWAP, MACD bear cross, hist-",
                          stop_loss=sl, take_profit=tp,
                          extras={"vwap": float(vwap_arr[-1]), "macd_hist": float(hist[-1])})

        return self._flat(asset, price, self.name, self.timeframe, "no setup")

    def _score(self, price, vwap_val, hist, side):
        edge = 60.0
        vwap_dist_pct = abs(price - vwap_val) / max(1e-9, vwap_val) * 100
        edge += min(20, vwap_dist_pct * 5)
        if len(hist) >= 3 and np.isfinite(hist[-3]):
            if abs(hist[-1]) > abs(hist[-3]):
                edge += 10
        return min(95, edge)
