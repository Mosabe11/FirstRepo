"""
execution/position.py — Position dataclass + TP/SL/breakeven/trailing state machine
"""
from dataclasses import dataclass, field
from typing import Literal
import time
import uuid

from config import settings


@dataclass
class Position:
    id: str
    asset: str
    direction: Literal["LONG", "SHORT"]
    entry_price: float
    quantity: float
    stop_loss: float
    take_profit: float
    strategy: str
    opened_at: float = field(default_factory=time.time)
    breakeven_armed: bool = False
    trailing_armed: bool = False
    high_water_mark: float = 0.0
    low_water_mark: float = 0.0
    paper: bool = True

    @classmethod
    def new(cls, asset, direction, entry, qty, sl, tp, strategy, paper):
        return cls(
            id=uuid.uuid4().hex[:10],
            asset=asset, direction=direction, entry_price=entry,
            quantity=qty, stop_loss=sl, take_profit=tp,
            strategy=strategy,
            high_water_mark=entry, low_water_mark=entry,
            paper=paper,
        )

    def pnl(self, current_price):
        if self.direction == "LONG":
            return (current_price - self.entry_price) * self.quantity
        return (self.entry_price - current_price) * self.quantity

    def pnl_pct(self, current_price):
        if self.entry_price == 0:
            return 0.0
        if self.direction == "LONG":
            return (current_price - self.entry_price) / self.entry_price
        return (self.entry_price - current_price) / self.entry_price

    def update(self, price):
        if self.direction == "LONG":
            self.high_water_mark = max(self.high_water_mark, price)
            if price >= self.take_profit:
                return "TP"
            if price <= self.stop_loss:
                return "TRAIL" if self.trailing_armed else "SL"
            if not self.breakeven_armed:
                if self.pnl_pct(price) >= settings.BREAKEVEN_TRIGGER_PCT:
                    self.stop_loss = self.entry_price
                    self.breakeven_armed = True
            if self.breakeven_armed:
                trail_sl = self.high_water_mark * (1 - settings.TRAILING_DISTANCE_PCT)
                if trail_sl > self.stop_loss:
                    self.stop_loss = trail_sl
                    self.trailing_armed = True
            return "HOLD"
        else:
            self.low_water_mark = min(self.low_water_mark, price) if self.low_water_mark else price
            if price <= self.take_profit:
                return "TP"
            if price >= self.stop_loss:
                return "TRAIL" if self.trailing_armed else "SL"
            if not self.breakeven_armed:
                if self.pnl_pct(price) >= settings.BREAKEVEN_TRIGGER_PCT:
                    self.stop_loss = self.entry_price
                    self.breakeven_armed = True
            if self.breakeven_armed:
                trail_sl = self.low_water_mark * (1 + settings.TRAILING_DISTANCE_PCT)
                if trail_sl < self.stop_loss:
                    self.stop_loss = trail_sl
                    self.trailing_armed = True
            return "HOLD"

    def to_dict(self):
        return {
            "id": self.id, "asset": self.asset, "direction": self.direction,
            "entry_price": self.entry_price, "quantity": self.quantity,
            "stop_loss": self.stop_loss, "take_profit": self.take_profit,
            "strategy": self.strategy, "opened_at": self.opened_at,
            "breakeven_armed": self.breakeven_armed,
            "trailing_armed": self.trailing_armed,
            "paper": self.paper,
        }

    @classmethod
    def from_dict(cls, d):
        return cls(
            id=d["id"], asset=d["asset"], direction=d["direction"],
            entry_price=d["entry_price"], quantity=d["quantity"],
            stop_loss=d["stop_loss"], take_profit=d["take_profit"],
            strategy=d["strategy"],
            opened_at=d.get("opened_at", time.time()),
            breakeven_armed=d.get("breakeven_armed", False),
            trailing_armed=d.get("trailing_armed", False),
            high_water_mark=d["entry_price"],
            low_water_mark=d["entry_price"],
            paper=d.get("paper", True),
        )
