"""
execution/paper.py — Paper trading executor with slippage
"""
import logging
import random

logger = logging.getLogger(__name__)

SLIPPAGE_BPS_MIN = 1
SLIPPAGE_BPS_MAX = 6


def _slippage_factor(direction):
    bps = random.uniform(SLIPPAGE_BPS_MIN, SLIPPAGE_BPS_MAX)
    bps_decimal = bps / 10_000
    return (1 + bps_decimal) if direction == "LONG" else (1 - bps_decimal)


def submit_order(asset_class, exchange_symbol, direction, quantity, expected_price):
    if quantity <= 0:
        return {"filled": False, "fill_price": 0, "fee": 0, "error": "qty must be > 0"}
    fill_price = expected_price * _slippage_factor(direction)
    fee = abs(fill_price * quantity) * 0.0002
    logger.info(f"[PAPER] {direction} {quantity} {exchange_symbol} @ {fill_price:.6f}")
    return {
        "filled": True,
        "fill_price": float(fill_price),
        "fee": float(fee),
        "error": None,
        "mode": "paper",
    }


def close_order(asset_class, exchange_symbol, direction, quantity, expected_price):
    closing_side = "SHORT" if direction == "LONG" else "LONG"
    return submit_order(asset_class, exchange_symbol, closing_side, quantity, expected_price)
