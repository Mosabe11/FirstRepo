"""
execution/router.py — Single switching point for paper vs live
"""
from config import settings
from execution import paper, live_mexc


def is_live():
    return bool(settings.LIVE_MODE and settings.MEXC_API_KEY and settings.MEXC_API_SECRET)


def submit_order(asset_class, exchange_symbol, direction, quantity, expected_price):
    if is_live():
        return live_mexc.submit_order(asset_class, exchange_symbol, direction, quantity, expected_price)
    return paper.submit_order(asset_class, exchange_symbol, direction, quantity, expected_price)


def close_order(asset_class, exchange_symbol, direction, quantity, expected_price):
    if is_live():
        return live_mexc.close_order(asset_class, exchange_symbol, direction, quantity, expected_price)
    return paper.close_order(asset_class, exchange_symbol, direction, quantity, expected_price)


def mode_label():
    return "LIVE" if is_live() else "PAPER"
