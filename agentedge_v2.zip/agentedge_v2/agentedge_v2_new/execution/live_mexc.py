"""
execution/live_mexc.py — LIVE executor for MEXC + Binance
"""
import logging
import threading
from typing import Optional

import ccxt

from config import settings

logger = logging.getLogger(__name__)

_mexc_lock = threading.Lock()
_mexc: Optional[ccxt.mexc] = None
_binance_lock = threading.Lock()
_binance: Optional[ccxt.binance] = None


def _get_mexc():
    global _mexc
    with _mexc_lock:
        if _mexc is None:
            if not settings.MEXC_API_KEY or not settings.MEXC_API_SECRET:
                raise RuntimeError("LIVE mode requires MEXC keys")
            _mexc = ccxt.mexc({
                "apiKey": settings.MEXC_API_KEY,
                "secret": settings.MEXC_API_SECRET,
                "enableRateLimit": True, "timeout": 15000,
                "options": {"defaultType": "spot"},
            })
        return _mexc


def _get_binance():
    global _binance
    with _binance_lock:
        if _binance is None:
            if not settings.BINANCE_API_KEY or not settings.BINANCE_API_SECRET:
                raise RuntimeError("LIVE mode requires Binance keys")
            _binance = ccxt.binance({
                "apiKey": settings.BINANCE_API_KEY,
                "secret": settings.BINANCE_API_SECRET,
                "enableRateLimit": True, "timeout": 15000,
                "options": {"defaultType": "spot"},
            })
        return _binance


def submit_order(asset_class, exchange_symbol, direction, quantity, expected_price):
    if asset_class not in ("crypto", "binance"):
        return {"filled": False, "fill_price": 0, "fee": 0,
                "error": f"live trading not supported for {asset_class}"}
    if direction == "SHORT":
        return {"filled": False, "fill_price": 0, "fee": 0,
                "error": "live shorts require futures (spot is long-only)"}
    try:
        client = _get_mexc() if asset_class == "crypto" else _get_binance()
        order = client.create_order(
            symbol=exchange_symbol, type="market",
            side="buy" if direction == "LONG" else "sell",
            amount=quantity,
        )
        avg = float(order.get("average") or order.get("price") or expected_price)
        fee = 0.0
        fees = order.get("fees") or []
        if fees:
            try:
                fee = float(fees[0].get("cost", 0))
            except Exception:
                pass
        logger.warning(f"[LIVE] {direction} {quantity} {exchange_symbol} @ {avg}")
        return {"filled": True, "fill_price": avg, "fee": fee,
                "error": None, "mode": "live", "order_id": order.get("id")}
    except Exception as e:
        logger.error(f"[LIVE] order failed: {e}")
        return {"filled": False, "fill_price": 0, "fee": 0, "error": str(e)}


def close_order(asset_class, exchange_symbol, direction, quantity, expected_price):
    opposite = "SHORT" if direction == "LONG" else "LONG"
    return submit_order(asset_class, exchange_symbol, opposite, quantity, expected_price)
