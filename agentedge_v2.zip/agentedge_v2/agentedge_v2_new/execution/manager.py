"""
execution/manager.py — Central position registry + trade lifecycle.
Includes Telegram notifications and per-strategy learning stats.
"""
import time
import logging
import threading

from config import settings, watchlist
from core.signal import Signal
from core.risk import risk_manager
from core import market_data
from core import ai_confirm
from core.notify import tg_send
from execution import router
from execution.position import Position
from storage import state as state_store

logger = logging.getLogger(__name__)


class PositionManager:
    def __init__(self):
        self._positions = {}
        self._lock = threading.RLock()
        self._trades = []
        self._learning = {}
        self._load()

    def _load(self):
        st = state_store.load_state()
        for p in st.get("positions", []):
            try:
                pos = Position.from_dict(p)
                self._positions[pos.id] = pos
            except Exception as e:
                logger.warning(f"Skipped malformed position: {e}")
        self._trades = st.get("trades", [])
        self._learning = st.get("learning", {})
        logger.info(f"Loaded {len(self._positions)} positions, {len(self._trades)} historical trades")

    def _save(self):
        state_store.save_state({
            "positions": [p.to_dict() for p in self._positions.values()],
            "trades": self._trades[-500:],
            "learning": self._learning,
        })

    def open_positions(self):
        with self._lock:
            return list(self._positions.values())

    def has_position_on(self, asset):
        with self._lock:
            return any(p.asset == asset for p in self._positions.values())

    def asset_win_rate(self, asset):
        stats = self._learning.get(asset, {})
        wins = stats.get("wins", 0)
        losses = stats.get("losses", 0)
        total = wins + losses
        return wins / total if total >= 5 else 0.5

    def stats(self):
        with self._lock:
            wins = sum(1 for t in self._trades if t.get("pnl", 0) > 0)
            losses = sum(1 for t in self._trades if t.get("pnl", 0) <= 0)
            total_pnl = sum(t.get("pnl", 0) for t in self._trades)
            total = wins + losses
            return {
                "open_positions": len(self._positions),
                "total_trades": total,
                "wins": wins,
                "losses": losses,
                "win_rate": round(wins / total * 100, 1) if total else 0,
                "total_pnl": round(total_pnl, 2),
                "mode": router.mode_label(),
            }

    def recent_trades(self, n=20):
        with self._lock:
            return self._trades[-n:][::-1]

    def try_open(self, signal, asset_cfg, use_ai=True):
        if not signal.is_actionable:
            return False, "signal not actionable"

        with self._lock:
            ok, reason = risk_manager.pre_trade_check(
                signal.asset, list(self._positions.values()),
                self.has_position_on(signal.asset),
            )
        if not ok:
            return False, reason

        current_price = market_data.fetch_price(asset_cfg.asset_class, asset_cfg.exchange_symbol)
        if current_price is None:
            return False, "could not fetch current price"
        drift = abs(current_price - signal.price) / signal.price
        if drift > settings.MAX_PRICE_DRIFT:
            return False, f"price drifted {drift*100:.2f}%"

        if use_ai and settings.DEEPSEEK_KEY:
            decision, confidence = ai_confirm.confirm_trade(
                signal.asset, signal.direction, current_price, signal.extras or {},
            )
            if decision is not None:
                wanted = "BUY" if signal.direction == "LONG" else "SELL"
                if decision != wanted:
                    return False, f"AI says {decision} (conf {confidence:.0f})"
                if confidence < settings.AI_MIN_CONFIDENCE:
                    return False, f"AI confidence {confidence:.0f} below threshold"

        qty = risk_manager.position_size(
            asset_cfg.base_qty, signal.edge, self.asset_win_rate(signal.asset)
        )

        result = router.submit_order(
            asset_cfg.asset_class, asset_cfg.exchange_symbol,
            signal.direction, qty, current_price,
        )
        if not result["filled"]:
            return False, f"execution failed: {result.get('error')}"

        entry = result["fill_price"]
        if signal.stop_loss and signal.take_profit:
            sl, tp = signal.stop_loss, signal.take_profit
        else:
            if signal.direction == "LONG":
                sl = entry * (1 - asset_cfg.sl_pct)
                tp = entry * (1 + asset_cfg.tp_pct)
            else:
                sl = entry * (1 + asset_cfg.sl_pct)
                tp = entry * (1 - asset_cfg.tp_pct)

        pos = Position.new(
            asset=signal.asset, direction=signal.direction,
            entry=entry, qty=qty, sl=sl, tp=tp,
            strategy=signal.strategy, paper=not router.is_live(),
        )

        with self._lock:
            self._positions[pos.id] = pos
            self._save()
        risk_manager.record_trade_opened(signal.asset)
        logger.info(f"OPENED {pos.direction} {pos.asset} qty={pos.quantity} entry={pos.entry_price:.6f}")

        # Notification
        tg_send(
            f"✅ *OPENED* {pos.direction} `{pos.asset}`\n"
            f"Entry: {pos.entry_price:.4f}\n"
            f"Qty: {pos.quantity}\n"
            f"SL: {pos.stop_loss:.4f}\n"
            f"TP: {pos.take_profit:.4f}\n"
            f"Strategy: {pos.strategy}\n"
            f"Edge: {signal.edge:.0f}\n"
            f"Reason: {signal.reason}",
            category="open_close",
        )
        return True, f"opened {pos.id}"

    def close_position(self, position_id, reason):
        with self._lock:
            pos = self._positions.get(position_id)
            if not pos:
                return False, "position not found"

        cfg = watchlist.to_dict().get(pos.asset)
        if not cfg:
            asset_class, exchange_symbol = "crypto", f"{pos.asset}/USDT"
        else:
            asset_class = cfg.asset_class
            exchange_symbol = cfg.exchange_symbol

        current_price = market_data.fetch_price(asset_class, exchange_symbol)
        if current_price is None:
            return False, "could not fetch current price"

        result = router.close_order(asset_class, exchange_symbol, pos.direction, pos.quantity, current_price)
        if not result["filled"]:
            return False, f"close failed: {result.get('error')}"

        exit_price = result["fill_price"]
        pnl = pos.pnl(exit_price)
        pnl_pct = pos.pnl_pct(exit_price)

        with self._lock:
            self._positions.pop(position_id, None)
            self._trades.append({
                "id": pos.id, "asset": pos.asset, "direction": pos.direction,
                "strategy": pos.strategy, "entry": pos.entry_price, "exit": exit_price,
                "qty": pos.quantity, "pnl": round(pnl, 4),
                "pnl_pct": round(pnl_pct * 100, 3),
                "reason": reason, "opened_at": pos.opened_at,
                "closed_at": time.time(),
                "mode": "live" if not pos.paper else "paper",
            })
            stats = self._learning.setdefault(pos.asset, {"wins": 0, "losses": 0, "by_strategy": {}})
            if pnl > 0:
                stats["wins"] += 1
            else:
                stats["losses"] += 1
            ss = stats["by_strategy"].setdefault(pos.strategy, {"wins": 0, "losses": 0})
            if pnl > 0:
                ss["wins"] += 1
            else:
                ss["losses"] += 1
            self._save()

        risk_manager.record_trade_closed(pnl)
        logger.info(f"CLOSED {pos.direction} {pos.asset} exit={exit_price:.6f} pnl={pnl:+.4f}")

        emoji = "🟢" if pnl > 0 else "🔴"
        tg_send(
            f"{emoji} *CLOSED* {pos.direction} `{pos.asset}`\n"
            f"Exit: {exit_price:.4f}\n"
            f"PnL: {pnl:+.4f} ({pnl_pct*100:+.2f}%)\n"
            f"Reason: {reason}\n"
            f"Strategy: {pos.strategy}",
            category="open_close",
        )
        return True, f"closed pnl={pnl:+.4f}"

    def close_all(self, reason="manual close_all"):
        results = []
        with self._lock:
            ids = list(self._positions.keys())
        for pid in ids:
            ok, msg = self.close_position(pid, reason)
            results.append((pid, ok, msg))
        return results

    def reset_paper(self):
        if router.is_live():
            return False
        with self._lock:
            self._positions.clear()
            self._trades.clear()
            self._learning.clear()
            self._save()
        return True


position_manager = PositionManager()
