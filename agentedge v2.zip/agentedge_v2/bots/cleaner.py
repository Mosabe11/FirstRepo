"""
bots/cleaner.py
---------------
Periodically prunes non-base assets that have a poor win-rate or
no recent activity. Never touches assets with open positions.
"""

from __future__ import annotations
import logging
import threading

from config import settings
from execution.manager import position_manager
from storage.watchlist_runtime import registry

logger = logging.getLogger(__name__)


class CleanerBot:
    name = "cleaner"

    def __init__(self):
        self._stop = threading.Event()

    def stop(self):
        self._stop.set()

    def run(self):
        logger.info("Cleaner bot started")
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception as e:
                logger.exception(f"Cleaner tick error: {e}")
            self._stop.wait(settings.CLEANER_INTERVAL)
        logger.info("Cleaner bot stopped")

    def _tick(self):
        if registry.size() <= len(registry.crypto_only()):
            pass  # always at least base size

        if registry.size() <= settings.WATCHLIST_MAX_SIZE * 0.8:
            return  # only clean when nearing capacity

        # rank non-base assets by win-rate ascending → weakest first
        non_base = [a for a in registry.all() if not a.is_base]
        if not non_base:
            return

        # don't touch anything with an open position
        held = {p.asset for p in position_manager.open_positions()}
        non_base = [a for a in non_base if a.symbol not in held]

        ranked = sorted(
            non_base,
            key=lambda a: position_manager.asset_win_rate(a.symbol)
        )

        # remove weakest 1-2 per tick
        for victim in ranked[:2]:
            wr = position_manager.asset_win_rate(victim.symbol)
            if wr >= 0.55:
                break  # don't kill anything that's actually working
            if registry.remove(victim.symbol):
                logger.info(f"Cleaner removed {victim.symbol} (wr={wr:.2f})")
