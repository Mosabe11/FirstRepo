"""
bots/monitor.py
---------------
Watches open positions every few seconds.
Pulls fresh prices, lets each Position update its state machine,
closes anything that hits TP / SL / trailing.
"""

from __future__ import annotations
import time
import logging
import threading

from config import settings
from core import market_data
from execution.manager import position_manager
from storage.watchlist_runtime import registry

logger = logging.getLogger(__name__)


class MonitorBot:
    name = "monitor"

    def __init__(self):
        self._stop = threading.Event()

    def stop(self):
        self._stop.set()

    def run(self):
        logger.info("Monitor bot started")
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception as e:
                logger.exception(f"Monitor tick error: {e}")
            self._stop.wait(settings.MONITOR_INTERVAL)
        logger.info("Monitor bot stopped")

    def _tick(self):
        positions = position_manager.open_positions()
        if not positions:
            return
        # bucket prices to avoid duplicate fetches
        seen_prices: dict[str, float | None] = {}
        for pos in positions:
            cfg = registry.get(pos.asset)
            if not cfg:
                continue
            key = (cfg.asset_class, cfg.exchange_symbol)
            if key in seen_prices:
                price = seen_prices[key]
            else:
                price = market_data.fetch_price(cfg.asset_class, cfg.exchange_symbol)
                seen_prices[key] = price
            if price is None:
                continue
            outcome = pos.update(price)
            if outcome != "HOLD":
                position_manager.close_position(pos.id, reason=outcome)
