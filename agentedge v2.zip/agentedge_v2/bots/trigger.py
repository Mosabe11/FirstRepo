"""
bots/trigger.py
---------------
High-frequency scalping bot.

For each asset in the watchlist:
  1. Fetch fresh 1m and 5m candles (cached)
  2. Run every enabled scalping strategy on the appropriate timeframe
  3. If any strategy fires a signal with edge >= TRIGGER_EDGE,
     route it through the position manager (which handles AI confirmation,
     risk checks, sizing, and execution)
  4. Respect cooldowns enforced by the risk manager

This is the bot that uses the 4 strategies from the PDF.
"""

from __future__ import annotations
import time
import logging
import threading

from config import settings
from core import market_data
from execution.manager import position_manager
from storage.watchlist_runtime import registry
from strategies import scalping_strategies

logger = logging.getLogger(__name__)


class TriggerBot:
    name = "trigger"

    def __init__(self):
        self._stop = threading.Event()
        # cache last candle fetch per (asset, timeframe) to refresh every ~30s
        self._last_candles: dict[tuple[str, str], tuple[float, list]] = {}

    def stop(self):
        self._stop.set()

    def run(self):
        if not scalping_strategies:
            logger.warning("No scalping strategies enabled — trigger bot exiting")
            return
        logger.info(f"Trigger bot started ({len(scalping_strategies)} strategies)")
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception as e:
                logger.exception(f"Trigger tick error: {e}")
            self._stop.wait(settings.TRIGGER_INTERVAL)
        logger.info("Trigger bot stopped")

    def _get_candles(self, asset_class: str, exchange_symbol: str,
                     timeframe: str, limit: int = 80) -> list[list]:
        key = (exchange_symbol, timeframe)
        now = time.time()
        cached = self._last_candles.get(key)
        ttl = 30 if timeframe == "1m" else 60
        if cached and now - cached[0] < ttl:
            return cached[1]
        data = market_data.fetch_ohlcv(asset_class, exchange_symbol, timeframe, limit)
        if data:
            self._last_candles[key] = (now, data)
        return data

    def _tick(self):
        assets = registry.all()
        for cfg in assets:
            if self._stop.is_set():
                return
            if position_manager.has_position_on(cfg.symbol):
                # cooldown is still enforced inside try_open if needed
                continue

            # group strategies by timeframe — fetch once per timeframe
            for strat in scalping_strategies:
                tf = strat.timeframe
                candles = self._get_candles(cfg.asset_class, cfg.exchange_symbol, tf)
                if len(candles) < strat.min_candles:
                    continue
                try:
                    signal = strat.evaluate(cfg.symbol, candles)
                except Exception as e:
                    logger.warning(f"{strat.name} on {cfg.symbol} threw: {e}")
                    continue
                if not signal.is_actionable:
                    continue
                if signal.edge < settings.TRIGGER_EDGE:
                    continue
                ok, msg = position_manager.try_open(signal, cfg, use_ai=True)
                if ok:
                    logger.info(f"[{strat.name}] {cfg.symbol} {signal.direction} "
                                f"edge={signal.edge:.0f} → {msg}")
                    break  # one strategy per asset per tick
                else:
                    logger.debug(f"[{strat.name}] {cfg.symbol} rejected: {msg}")
