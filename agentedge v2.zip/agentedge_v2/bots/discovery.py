"""
bots/discovery.py
-----------------
Scans MEXC for high-volume USDT pairs not in the watchlist and adds
the strongest candidates (up to WATCHLIST_MAX_SIZE).
"""

from __future__ import annotations
import logging
import threading

from config import settings
from config.watchlist import AssetConfig
from core import market_data
from storage.watchlist_runtime import registry

logger = logging.getLogger(__name__)


class DiscoveryBot:
    name = "discovery"

    def __init__(self):
        self._stop = threading.Event()

    def stop(self):
        self._stop.set()

    def run(self):
        logger.info("Discovery bot started")
        while not self._stop.is_set():
            try:
                self._tick()
            except Exception as e:
                logger.exception(f"Discovery tick error: {e}")
            self._stop.wait(settings.DISCOVERY_INTERVAL)
        logger.info("Discovery bot stopped")

    def _tick(self):
        if registry.size() >= settings.WATCHLIST_MAX_SIZE:
            return

        candidates = market_data.fetch_top_usdt_pairs(
            top_n=40, min_volume_usdt=settings.DISCOVERY_MIN_VOLUME_USDT
        )
        if not candidates:
            return

        # score: blend of volume and absolute percent change
        scored = []
        for c in candidates:
            sym = c["symbol"]
            if registry.get(sym) is not None:
                continue
            score = (c["quote_volume"] / 1e7) + abs(c.get("percent_change", 0))
            scored.append((score, c))
        scored.sort(reverse=True, key=lambda x: x[0])

        added = 0
        for score, c in scored[: settings.DISCOVERY_BATCH_SIZE]:
            if registry.size() >= settings.WATCHLIST_MAX_SIZE:
                break
            price = c.get("last", 0)
            if not price:
                continue
            # base_qty so that 1 unit ≈ small portion of a typical position
            target_notional = 25.0
            base_qty = max(0.0001, target_notional / price)
            base_qty = round(base_qty, 8)
            new_asset = AssetConfig(
                symbol=sym,
                exchange_symbol=c["exchange_symbol"],
                asset_class="crypto",
                base_qty=base_qty,
                tp_pct=0.015,
                sl_pct=0.008,
                is_base=False,
            )
            if registry.add(new_asset):
                added += 1
                logger.info(f"Discovery added {sym} (score={score:.1f})")
        if added:
            logger.info(f"Discovery: +{added}, watchlist now {registry.size()}")
