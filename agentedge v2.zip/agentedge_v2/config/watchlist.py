"""
config/watchlist.py
-------------------
Initial watchlist of assets. The Discovery bot will add more at runtime.
Each asset has its asset class (crypto/metal) which determines:
  - which data source (MEXC vs Yahoo)
  - which symbol format
  - default position sizing
"""

from dataclasses import dataclass


@dataclass
class AssetConfig:
    symbol: str           # display symbol e.g. "BTC"
    exchange_symbol: str  # how the exchange knows it e.g. "BTC/USDT" or "GC=F"
    asset_class: str      # "crypto" | "metal"
    base_qty: float       # base position size in units
    tp_pct: float = 0.015
    sl_pct: float = 0.008
    is_base: bool = True  # base assets are never auto-removed by the cleaner


BASE_WATCHLIST: list[AssetConfig] = [
    AssetConfig("BTC",    "BTC/USDT", "crypto", base_qty=0.001),
    AssetConfig("ETH",    "ETH/USDT", "crypto", base_qty=0.02),
    AssetConfig("XRP",    "XRP/USDT", "crypto", base_qty=50),
    AssetConfig("SOL",    "SOL/USDT", "crypto", base_qty=0.5),
    AssetConfig("GOLD",   "GC=F",     "metal",  base_qty=0.1,
                tp_pct=0.008, sl_pct=0.004),
    AssetConfig("SILVER", "SI=F",     "metal",  base_qty=1.0,
                tp_pct=0.012, sl_pct=0.006),
]


def to_dict() -> dict[str, AssetConfig]:
    return {a.symbol: a for a in BASE_WATCHLIST}
