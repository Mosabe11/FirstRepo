"""
execution/manager.py
--------------------
Central position registry + trade lifecycle orchestration.

Anything that wants to open or close a trade goes through here. It enforces
risk checks, routes execution, persists state, and tracks per-asset
per-strategy learning stats.
"""

from __future__ import annotations
import time
import logging
import threading
from typing import Optional

from config import settings, watchlist
from core.signal import Signal
from core.risk import risk_manager
from core import market_data
from core import ai_confirm
from execution import router
from execution.position import Position
from storage import state as state_store

logger = logging.getLogger(__name__)


class PositionManager:
    def __init__(self):
        self._positions: dict[str, Position] = {}  # position_id -> Position
        self._lock = threading.RLock()
        self._trades: list[dict] = []  # closed-trade log
        self._learning: dict[str, dict] = {}  # asset+strategy stats
        self._load()

    # ------------------- persistence -------------------
    def _load(self):
        st = state_store.load_state()
        for p in st.get("positions", []):
            try:
                pos = Position.from_dict(p)
                self._positions[pos.id] = pos
            except Exception as e:
                logger.warning(f"Skipped malformed position: {e}")
        self._trades = st.get("trades", [])
        self._learning = st.get("learning", {})
        logger.info(f"Loaded {len(self._positions)} positions, "
                    f"{len(self._trades)} historical trades")

    def _save(self):
        state_store.save_state({
            "positions": [p.to_dict() for p in self._positions.values()],
            "trades": self._trades[-500:],   # cap log
            "learning": self._learning,
        })

    # ------------------- queries -------------------
    def open_positions(self) -> list[Position]:
        with self._lock:
            return list(self._positions.values())

    def has_position_on(self, asset: str) -> bool:
        with self._lock:
            return any(p.asset == asset for p in self._positions.values())

    def asset_win_rate(self, asset: str) -> float:
        """Win rate from learning stats. Defaults to 0.5 for unknown assets."""
        stats = self._learning.get(asset, {})
        wins = stats.get("wins", 0)
        losses = stats.get("losses", 0)
        total = wins + losses
        return wins / total if total >= 5 else 0.5

    def stats(self) -> dict:
        with self._lock:
            wins = sum(1 for t in self._trades if t.get("pnl", 0) > 0)
            losses = sum(1 for t in self._trades if t.get("pnl", 0) <= 0)
            total_pnl = sum(t.get("pnl", 0) for t in self._trades)
            total = wins + losses
            return {
                "open_positions": len(self._positions),
                "total_trades": total,
                "wins": wins,
                "losses": losses,
                "win_rate": round(wins / total * 100, 1) if total else 0,
                "total_pnl": round(total_pnl, 2),
                "mode": router.mode_label(),
            }

    def recent_trades(self, n: int = 20) -> list[dict]:
        with self._lock:
            return self._trades[-n:][::-1]

    # ------------------- open -------------------
    def try_open(self, signal: Signal, asset_cfg, use_ai: bool = True) -> tuple[bool, str]:
        """
        Apply gatekeeping, AI confirmation, and place the order.
        Returns (success, message).
        """
        if not signal.is_actionable:
            return False, "signal not actionable"

        # Risk check
        with self._lock:
            ok, reason = risk_manager.pre_trade_check(
                signal.asset,
                list(self._positions.values()),
                self.has_position_on(signal.asset),
            )
        if not ok:
            return False, reason

        # Price drift sanity (current vs signal price)
        current_price = market_data.fetch_price(
            asset_cfg.asset_class, asset_cfg.exchange_symbol
        )
        if current_price is None:
            return False, "could not fetch current price"
        drift = abs(current_price - signal.price) / signal.price
        if drift > settings.MAX_PRICE_DRIFT:
            return False, f"price drifted {drift*100:.2f}% > {settings.MAX_PRICE_DRIFT*100}%"

        # AI confirmation
        if use_ai and settings.DEEPSEEK_KEY:
            decision, confidence = ai_confirm.confirm_trade(
                signal.asset, signal.direction, current_price,
                signal.extras or {},
            )
            if decision is not None:  # AI responded
                wanted = "BUY" if signal.direction == "LONG" else "SELL"
                if decision != wanted:
                    return False, f"AI says {decision} (conf {confidence:.0f})"
                if confidence < settings.AI_MIN_CONFIDENCE:
                    return False, f"AI confidence {confidence:.0f} below threshold"

        # Sizing
        qty = risk_manager.position_size(
            asset_cfg.base_qty, signal.edge, self.asset_win_rate(signal.asset)
        )

        # Submit
        result = router.submit_order(
            asset_cfg.asset_class, asset_cfg.exchange_symbol,
            signal.direction, qty, current_price,
        )
        if not result["filled"]:
            return False, f"execution failed: {result.get('error')}"

        # Build position with strategy-supplied SL/TP if available,
        # otherwise default to asset-class percentages.
        entry = result["fill_price"]
        if signal.stop_loss and signal.take_profit:
            sl, tp = signal.stop_loss, signal.take_profit
        else:
            if signal.direction == "LONG":
                sl = entry * (1 - asset_cfg.sl_pct)
                tp = entry * (1 + asset_cfg.tp_pct)
            else:
                sl = entry * (1 + asset_cfg.sl_pct)
                tp = entry * (1 - asset_cfg.tp_pct)

        pos = Position.new(
            asset=signal.asset, direction=signal.direction,
            entry=entry, qty=qty, sl=sl, tp=tp,
            strategy=signal.strategy, paper=not router.is_live(),
        )

        with self._lock:
            self._positions[pos.id] = pos
            self._save()
        risk_manager.record_trade_opened(signal.asset)
        logger.info(f"OPENED {pos.direction} {pos.asset} qty={pos.quantity} "
                    f"entry={pos.entry_price:.6f} SL={pos.stop_loss:.6f} "
                    f"TP={pos.take_profit:.6f} strategy={pos.strategy}")
        return True, f"opened {pos.id}"

    # ------------------- close -------------------
    def close_position(self, position_id: str, reason: str) -> tuple[bool, str]:
        with self._lock:
            pos = self._positions.get(position_id)
            if not pos:
                return False, "position not found"

        asset_cfg = watchlist.to_dict().get(pos.asset)
        if not asset_cfg:
            asset_class = "crypto"
            exchange_symbol = f"{pos.asset}/USDT"
        else:
            asset_class = asset_cfg.asset_class
            exchange_symbol = asset_cfg.exchange_symbol

        current_price = market_data.fetch_price(asset_class, exchange_symbol)
        if current_price is None:
            return False, "could not fetch current price for close"

        result = router.close_order(
            asset_class, exchange_symbol, pos.direction,
            pos.quantity, current_price,
        )
        if not result["filled"]:
            return False, f"close failed: {result.get('error')}"

        exit_price = result["fill_price"]
        pnl = pos.pnl(exit_price)
        pnl_pct = pos.pnl_pct(exit_price)

        with self._lock:
            self._positions.pop(position_id, None)
            self._trades.append({
                "id": pos.id,
                "asset": pos.asset,
                "direction": pos.direction,
                "strategy": pos.strategy,
                "entry": pos.entry_price,
                "exit": exit_price,
                "qty": pos.quantity,
                "pnl": round(pnl, 4),
                "pnl_pct": round(pnl_pct * 100, 3),
                "reason": reason,
                "opened_at": pos.opened_at,
                "closed_at": time.time(),
                "mode": "live" if not pos.paper else "paper",
            })
            # learning stats
            key = pos.asset
            stats = self._learning.setdefault(key, {"wins": 0, "losses": 0, "by_strategy": {}})
            if pnl > 0:
                stats["wins"] += 1
            else:
                stats["losses"] += 1
            ss = stats["by_strategy"].setdefault(pos.strategy, {"wins": 0, "losses": 0})
            if pnl > 0:
                ss["wins"] += 1
            else:
                ss["losses"] += 1
            self._save()

        risk_manager.record_trade_closed(pnl)
        logger.info(f"CLOSED {pos.direction} {pos.asset} exit={exit_price:.6f} "
                    f"pnl={pnl:+.4f} ({pnl_pct*100:+.2f}%) reason={reason}")
        return True, f"closed pnl={pnl:+.4f}"

    def close_all(self, reason: str = "manual close_all") -> list[tuple[str, bool, str]]:
        results = []
        with self._lock:
            ids = list(self._positions.keys())
        for pid in ids:
            ok, msg = self.close_position(pid, reason)
            results.append((pid, ok, msg))
        return results

    def reset_paper(self) -> bool:
        """Wipe state (paper only — refuses in live)."""
        if router.is_live():
            return False
        with self._lock:
            self._positions.clear()
            self._trades.clear()
            self._learning.clear()
            self._save()
        return True


# global singleton
position_manager = PositionManager()
